/* المهام والاستطلاعات (اربح مع m1li) — كتتصل بـ GET /api/tasks و POST /api/tasks/:id/submit */
(function () {
  var ICON = { app: '📱', survey: '📝', ad: '📣', other: '✨' };
  var KIND = { app: 'تطبيق', survey: 'استطلاع', ad: 'إعلان', other: 'مهمة' };
  var ST = { pending: ['قيد المراجعة', 'text-amber-300'], approved: ['مقبولة ✅', 'text-emerald-400'], rejected: ['مرفوضة', 'text-rose-400'] };
  var ERR = {
    unauthorized: 'خاصك تسجل الدخول باش تدير المهام', bad_proof: 'كتب إثبات واضح (رابط ولا وصف، 3 حروف على الأقل)',
    already_submitted: 'سبق ليك درتي هاد المهمة', task_full: 'هاد المهمة كملات', account_too_new: 'الحساب جديد بزاف، عاود حاول من بعد',
    too_many_pending: 'عندك مهام بزاف قيد المراجعة', rate_limited: 'محاولات بزاف، جرّب من بعد', not_found: 'المهمة ما بقاتش متاحة',
    not_image: 'الملف خاصو يكون صورة (JPG / PNG / WEBP)', bad_file_type: 'الملف خاصو يكون صورة (JPG / PNG / WEBP)', too_large: 'الصورة كبيرة بزاف',
    phone_unverified: 'خاصك تأكد رقم الهاتف قبل رفع الصور', google_required: 'خاصك حساب Google باش ترفع الصور',
    tasks_table_missing: 'المهام غير متاحة دابا', network: 'تعذّر الاتصال بالسيرفر'
  };
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function T(m) { if (typeof toast === 'function') toast(m); }
  function safe(u) { return /^https:\/\//i.test(u || '') ? u : ''; }

  function card(t) {
    var c = el('div', 'bg-slate-800/60 border border-slate-700 rounded-2xl p-4 space-y-2');
    var head = el('div', 'flex items-start justify-between gap-3');
    var left = el('div', 'min-w-0');
    left.appendChild(el('div', 'font-bold text-white text-sm', (ICON[t.kind] || '✨') + ' ' + t.title));
    left.appendChild(el('span', 'inline-block text-[10px] px-2 py-0.5 rounded-full border bg-indigo-500/15 text-indigo-300 border-indigo-500/30 mt-1', KIND[t.kind] || 'مهمة'));
    head.appendChild(left);
    head.appendChild(el('div', 'text-xs text-amber-300 shrink-0 text-left', '+' + t.points + ' نقطة' + (t.mad ? ' (' + t.mad + ' د.م)' : '')));
    c.appendChild(head);
    if (t.desc) c.appendChild(el('p', 'text-xs text-slate-400 leading-relaxed', t.desc));
    var url = safe(t.url);
    if (url) { var a = el('a', 'inline-block text-xs underline text-brand-400', 'فتح الرابط ↗'); a.href = url; a.target = '_blank'; a.rel = 'noopener noreferrer nofollow'; c.appendChild(a); }
    if (t.mine) {
      var s = ST[t.mine.status] || ['—', 'text-slate-400'];
      c.appendChild(el('div', 'text-xs ' + s[1], s[0] + (t.mine.status === 'approved' && t.mine.points ? ' · +' + t.mine.points + ' نقطة' : '') + (t.mine.note && t.mine.status !== 'approved' ? ' — ' + t.mine.note : '')));
      return c;
    }
    if (!window.M1Views || !M1Views.session()) {
      var lg = el('button', 'px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white keep-white rounded-xl text-xs font-bold', 'سجّل الدخول باش تدير هاد المهمة');
      lg.type = 'button';
      lg.onclick = function () { if (typeof switchTab === 'function') switchTab('developer'); };
      c.appendChild(lg);
      return c;
    }
    var row = el('div', 'flex gap-2');
    var inp = el('input', 'flex-1 px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs');
    inp.maxLength = 300; inp.placeholder = 'الإثبات: رابط، وصف قصير، ولا صورة 📷';
    var file = el('input'); file.type = 'file'; file.accept = 'image/jpeg,image/png,image/webp'; file.style.display = 'none';
    var cam = el('button', 'px-3 py-2 bg-slate-700 hover:bg-slate-600 text-white keep-white rounded-xl text-xs', '📷');
    cam.type = 'button'; cam.setAttribute('aria-label', 'رفع صورة كإثبات');
    cam.onclick = function () { file.click(); };
    file.onchange = function () {
      var f = file.files && file.files[0]; if (!f) return;
      if (!/\.(jpe?g|png|webp)$/i.test(f.name)) { T(ERR.not_image); file.value = ''; return; }
      cam.disabled = true; cam.textContent = '...';
      M1Views.uploadFile(f).then(function (r) {
        cam.disabled = false; cam.textContent = '📷'; file.value = '';
        if (r.ok && r.url && r.url.length <= 300) { inp.value = r.url; T('تحمّلات الصورة ✅ دابا ضغط «سلّم»'); }
        else T(r.ok ? 'رابط الصورة طويل بزاف، جرّب صورة أخرى' : (ERR[r.error] || 'تعذّر رفع الصورة'));
      });
    };
    var b = el('button', 'px-4 py-2 bg-brand-600 hover:bg-brand-700 text-white keep-white rounded-xl text-xs font-bold', 'سلّم');
    b.type = 'button';
    b.onclick = function () {
      var v = inp.value.trim();
      if (v.length < 3) { T(ERR.bad_proof); return; }
      b.disabled = true;
      M1Views.taskSubmit(t.id, v).then(function (r) {
        if (r.ok) { T('توصلنا بالإثبات، غادي نراجعوه ✅'); load(); }
        else { b.disabled = false; T(ERR[r.error] || 'وقع خطأ، عاود حاول'); }
      });
    };
    row.appendChild(inp); row.appendChild(cam); row.appendChild(b); row.appendChild(file); c.appendChild(row);
    c.appendChild(el('p', 'text-[10px] text-slate-500', 'الصورة كتتنشر برابط عمومي، ما تصوّر حتى شي معلومة حساسة.'));
    return c;
  }

  function box() {
    var b = document.getElementById('tasks-box');
    if (b) return b;
    var anchor = document.getElementById('earn-login');
    if (!anchor || !anchor.parentNode) return null;
    b = el('div', 'space-y-3'); b.id = 'tasks-box';
    anchor.parentNode.insertBefore(b, anchor);
    return b;
  }
  function load() {
    var b = box(); if (!b || !window.M1Views || !M1Views.configured) return;
    M1Views.tasks().then(function (j) {
      b.innerHTML = '';
      if (!j || !j.items || !j.items.length) { if (j) b.style.display = 'none'; return; }
      b.style.display = '';
      b.appendChild(el('h3', 'font-bold text-white', '🎯 مهام واستطلاعات'));
      b.appendChild(el('p', 'text-xs text-slate-400', 'دير المهمة، سلّم الإثبات، ومن بعد المراجعة كتجيك النقاط (كتبقى معلّقة ' + (j.holdDays || 0) + ' أيام).'));
      j.items.forEach(function (t) { b.appendChild(card(t)); });
    });
  }
  window.loadEarnTasks = load;
  if (typeof window.renderEarn === 'function') {
    var orig = window.renderEarn;
    window.renderEarn = function () { var r = orig.apply(this, arguments); setTimeout(load, 400); return r; };
  }
})();
