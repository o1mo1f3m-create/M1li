// الاستعمال:  node apply-adsense.js pub-1234567890123456 [adSlot]
// كيعمّر: ads.txt + config.js + كود AdSense فـ <head> ديال كل الصفحات.
const fs = require('fs');
const pub = (process.argv[2] || '').replace(/^ca-/, '');
const slot = process.argv[3] || '';
if (!/^pub-\d{10,20}$/.test(pub)) { console.log('خاصك تعطي Publisher ID بحال: pub-1234567890123456'); process.exit(1); }
fs.writeFileSync('ads.txt', `google.com, ${pub}, DIRECT, f08c47fec0942fa0\n`);
let c = fs.readFileSync('config.js', 'utf8');
c = c.replace(/M1LI_ADSENSE_CLIENT = '.*?'/, `M1LI_ADSENSE_CLIENT = 'ca-${pub}'`);
if (slot) c = c.replace(/M1LI_ADSENSE_SLOT = '.*?'/, `M1LI_ADSENSE_SLOT = '${slot}'`);
fs.writeFileSync('config.js', c);
const snip = `<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-${pub}" crossorigin="anonymous"></script>`;
let n = 0;
for (const f of fs.readdirSync('.').filter(x => x.endsWith('.html'))) {
  let s = fs.readFileSync(f, 'utf8');
  const r = s.replace(/<!-- ADSENSE-SNIPPET -->(\s*<script async src="https:\/\/pagead2[^>]*><\/script>)?/, '<!-- ADSENSE-SNIPPET -->\n' + snip);
  if (r !== s) { fs.writeFileSync(f, r); n++; }
}
console.log('تمّ. تحدّثو', n, 'صفحات + ads.txt + config.js');
