/* ===== خدمات m1li: خدمات رقمية مصغرة · أرباح · حرفيون =====
   v34: القائمة كتجي من السيرفر (/api/listings?kind=service) + services.json، النشر والطلب بضمان m1li والمهام كيمشيو عبر السيرفر، وواتساب بقا احتياطي. */
(function () {
  var CATS = {
    digital: { label: 'خدمات رقمية', icon: 'fa-wand-magic-sparkles', subs: ['تصميم (Canva)', 'ترجمة وكتابة', 'تعليق صوتي', 'إدارة صفحات', 'مونتاج', 'برمجة/مواقع', 'تسويق', 'مساعدة تقنية'],
      note: '<b>أي شاب عندو تلفون وكونيكسيون</b> يقدر يقدّم خدمة صغيرة: <b>تصميم</b> (Miniatures، منشورات، شعارات)، <b>ترجمة وكتابة محتوى</b> (عربية/فرنسية/إنجليزية)، <b>تعليق صوتي</b>، أو <b>إدارة صفحات</b> وردّ على زبناء واتساب وإنستغرام.' },
    craft: { label: 'حرفيون', icon: 'fa-screwdriver-wrench', subs: ['تصليح هواتف', 'صباغة', 'تركيب أثاث', 'تنظيف', 'توصيل سريع', 'أخرى'],
      note: '<b>m1li = السوق الرقمي للمعلمين.</b> كتب رقمك والخدمة لي كتتقن، والزبون لي محتاجك فنفس المدينة كيعيط ليك مباشرة.' },
    earn: { label: 'أرباح', icon: 'fa-coins', subs: [], note: '' }
  };
  var S = { cat: 'digital', sub: '', q: '', city: '', items: [], loaded: false };
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var digits = function (s) { return String(s || '').replace(/\D/g, ''); };
  var admin = function () { return digits(window.M1LI_WHATSAPP); };
  /* ---- الإحالة: كنحفظو ?ref=CODE فاش كيجي شي واحد من رابط ديال رابح ---- */
  try {
    var qs = new URLSearchParams(location.search), rc = (qs.get('ref') || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 20);
    if (rc) localStorage.setItem('m1li_ref', JSON.stringify({ code: rc, sv: qs.get('sv') || '', t: Date.now() }));
    // (حيّدنا النداء /api/ref/click: ما كاينش هاد المسار فالسيرفر. العمولة كتتحسب غير ملي كيتكمل طلب خدمة بكود الإحالة.)
  } catch (e) {}
  function refSaved() { try { var r = JSON.parse(localStorage.getItem('m1li_ref') || 'null'); return r && Date.now() - r.t < 30 * 864e5 ? r.code : ''; } catch (e) { return ''; } }
  window.M1LI_REF = refSaved;
  function myRef() { return window.EARN && EARN.me && EARN.me.refCode ? EARN.me.refCode : ''; }
  window.svShare = function (id, title) {
    var code = myRef();
    if (!code) { alert('سجّل الدخول (مركز المطورين) وفتح صفحة «اربح» مرة وحدة باش يتعطيك الكود ديالك.'); switchTab('earn'); return; }
    var u = location.origin + location.pathname + '?ref=' + encodeURIComponent(code) + '&sv=' + encodeURIComponent(id);
    var txt = title + '\n' + u;
    if (navigator.share) navigator.share({ title: title, text: title, url: u }).catch(function () {});
    else { try { navigator.clipboard.writeText(txt); } catch (e) {} alert('تنسخ الرابط ديالك:\n' + u); }
  };

  var API = String(window.M1LI_API || '').replace(/\/+$/, '');
  function session() { try { var x = JSON.parse(localStorage.getItem('m1li_session') || 'null'); return x && x.token ? x : null; } catch (e) { return null; } }
  function api(method, path, body) {
    var h = {}, x = session(); if (x) h.Authorization = 'Bearer ' + x.token; if (body) h['Content-Type'] = 'application/json';
    if (!API) return Promise.resolve({ ok: false, error: 'network' });
    return fetch(API + path, { method: method, headers: h, cache: 'no-store', body: body ? JSON.stringify(body) : undefined })
      .then(function (r) { return r.json().catch(function () { return { ok: false, error: 'network' }; }); })
      .catch(function () { return { ok: false, error: 'network' }; });
  }
  var ERR = { unauthorized: 'سجّل الدخول أولاً (مركز المطورين).', phone_unverified: 'أكّد رقم هاتفك أولاً.', network: 'ما كاينش اتصال بالسيرفر.', rate_limited: 'محاولات كثيرة، جرّب من بعد.',
    bad_title: 'العنوان قصير بزاف.', bad_city: 'دخل المدينة.', bad_whatsapp: 'رقم الواتساب ما بانش صحيح.', bad_price: 'الثمن ما بانش صحيح.', too_many_listings: 'وصلتي للحد الأقصى ديال الإعلانات.',
    own_service: 'ما يمكنش تطلب خدمتك.', bad_amount: 'المبلغ خارج الحدود المسموحة.', too_many_open_orders: 'عندك طلبات بزاف فانتظار الدفع.', services_table_missing: 'نظام الطلبات ما مفعّلش فالسيرفر بعد.',
    tasks_table_missing: 'المهام ما مفعّلاش فالسيرفر بعد.', already_submitted: 'سبق ليك بعتي هاد المهمة.', task_full: 'هاد المهمة سالات.', account_too_new: 'الحساب جديد، جرّب من بعد 24 ساعة.',
    too_many_pending: 'عندك مهام بزاف قيد المراجعة.', bad_proof: 'كتب الإثبات (3 حروف على الأقل).', not_found: 'ما بقاش موجود.' };
  function errMsg(r) { return ERR[r && r.error] || 'وقع مشكل، عاود المحاولة.'; }
  function mapListing(l) {
    var sv = l.svc || {}, pr = Number(l.price) || 0;
    return { id: l.id, lid: l.id, cat: sv.svcat === 'craft' ? 'craft' : 'digital', sub: sv.sub || '', area: sv.area || '', title: l.title, name: l.seller || '', city: l.city || '', phone: l.whatsapp || '',
      price: pr > 0 ? pr + ' درهم' : 'حسب الاتفاق', priceNum: pr, desc: l.desc || '', photo: (l.images && l.images[0]) || '' };
  }

  function lsGet() { try { return JSON.parse(localStorage.getItem('m1li_services_sent') || '[]'); } catch (e) { return []; } }
  function lsSet(v) { try { localStorage.setItem('m1li_services_sent', JSON.stringify(v)); } catch (e) {} }

  function load() {
    if (S.loaded) return Promise.resolve();
    var local = fetch('services.json', { cache: 'no-cache' }).then(function (r) { return r.json(); })
      .then(function (d) { return Array.isArray(d.items) ? d.items : []; }).catch(function () { return []; });
    var remote = api('GET', '/api/listings?kind=service').then(function (r) { return r && r.ok && Array.isArray(r.items) ? r.items.map(mapListing) : []; });
    return Promise.all([remote, local]).then(function (a) { S.items = a[0].concat(a[1]); }).catch(function () { S.items = []; }).then(function () { S.loaded = true; });
  }

  function earnCards() {
    var rows = [
      ['fa-share-nodes', 'رابح / Promotor', 'بارطاجي عروض ومنتجات ديال تجار محليين أو خدمات رقمية، وكل بيعة تمت على يديك كتشد عليها عمولة واضحة فحسابك.'],
      ['fa-list-check', 'مهام بسيطة ومكافآت', 'جرّب تطبيقات، جاوب على استطلاعات، شوف إعلانات… مقابل نقاط كتتحول لأرباح حقيقية.'],
      ['fa-video', 'صوّر فيديو', 'صوّر فيديو على m1li، اجمع النقاط وسحبها دراهم.']
    ];
    return '<div class="sv-ear">' + rows.map(function (r) {
      return '<div class="sv-card"><div class="ico"><i class="fa-solid ' + r[0] + '"></i></div><div><h4>' + r[1] + '</h4><p>' + r[2] + '</p></div></div>';
    }).join('') + '</div><button type="button" class="sv-cta green" onclick="switchTab(\'earn\')"><i class="fa-solid fa-coins"></i> دخل لصفحة «اربح»</button>';
  }

  function listHtml() {
    var c = CATS[S.cat], q = S.q.trim().toLowerCase(), city = S.city.trim().toLowerCase();
    var cities = {};
    S.items.forEach(function (i) { if (i.cat === S.cat && i.city) cities[i.city] = 1; });
    var list = S.items.filter(function (i) {
      return i.cat === S.cat && (!S.sub || i.sub === S.sub) && (!city || String(i.city || '').toLowerCase() === city) &&
        (!q || (i.title + ' ' + (i.area || '') + ' ' + i.name + ' ' + i.desc + ' ' + i.sub).toLowerCase().indexOf(q) > -1);
    });
    var h = '<div class="sv-note">' + c.note + '</div>';
    h += '<div class="sv-chips"><button type="button" class="sv-chip ' + (!S.sub ? 'on' : '') + '" data-sub="">الكل</button>' +
      c.subs.map(function (s) { return '<button type="button" class="sv-chip ' + (S.sub === s ? 'on' : '') + '" data-sub="' + esc(s) + '">' + esc(s) + '</button>'; }).join('') + '</div>';
    h += '<div class="sv-filters"><input id="sv-q" value="' + esc(S.q) + '" placeholder="ابحث…"><select id="sv-city"><option value="">كل المدن</option>' +
      Object.keys(cities).sort().map(function (k) { return '<option ' + (k === S.city ? 'selected' : '') + '>' + esc(k) + '</option>'; }).join('') + '</select></div>';
    if (!list.length) {
      h += '<div class="acc-empty"><i class="fa-solid fa-store"></i>ما كاين حتى خدمة هنا بعد. كن أول واحد يسجّل!</div>';
    } else {
      h += '<div class="sv-grid">' + list.map(function (i) {
        var p = digits(i.phone), rf = refSaved(), msg = encodeURIComponent('السلام عليكم، شفت خدمتك «' + i.title + '» فـ m1li وكنبغي نعرف أكثر.' + (rf ? '\n[ref:' + rf + ']' : ''));
        var img = /^https:\/\//i.test(i.photo || '') ? '<img src="' + esc(i.photo) + '" alt="" loading="lazy" style="width:100%;height:130px;object-fit:cover;border-radius:12px">' : '';
        return '<div class="sv-card">' + img + '<h4>' + esc(i.title) + '</h4><div class="sv-meta"><span><i class="fa-solid fa-user"></i> ' + esc(i.name) + '</span>' +
          (i.city ? '<span><i class="fa-solid fa-location-dot"></i> ' + esc(i.city) + (i.area ? ' — ' + esc(i.area) : '') + '</span>' : '') + '<span>' + esc(i.sub) + '</span></div>' +
          deliveryParts(i.desc, i.includes) + (i.price ? '<div class="sv-price">' + esc(i.price) + '</div>' : '') +
          (i.lid ? '<div class="sv-actions"><button type="button" class="sv-wa" data-order="' + esc(i.lid) + '" style="background:#059669;color:#fff;border:0;cursor:pointer"><i class="fa-solid fa-shield-halved"></i> اطلب بضمان m1li</button></div>' : '') +
          (i.id ? '<div class="sv-actions"><button type="button" class="sv-tel" data-share="' + esc(i.id) + '" data-st="' + esc(i.title) + '" style="cursor:pointer"><i class="fa-solid fa-share-nodes"></i> بارطاجي واربح عمولة</button></div>' : '') +
          (p ? '<div class="sv-actions"><a class="sv-wa" target="_blank" rel="noopener" href="https://wa.me/' + p + '?text=' + msg + '">واتساب</a><a class="sv-tel" href="tel:+' + p + '">اتصال</a></div>' : '') + '</div>';
      }).join('') + '</div>';
    }
    h += '<button type="button" class="sv-cta" id="sv-add"><i class="fa-solid fa-plus"></i> ' + (S.cat === 'craft' ? 'سجّل حرفتك' : 'اعرض خدمتك') + '</button>';
    return h;
  }

  function formHtml() {
    var subs = CATS[S.cat].subs;
    return '<form class="sv-form home-glass" style="padding:14px;border-radius:16px" id="sv-form"><h3 style="color:#fff;font-weight:800">' + (S.cat === 'craft' ? 'سجّل حرفتك' : 'اعرض خدمتك') + '</h3>' +
      '<div><label>الاسم</label><input name="name" required maxlength="40"></div>' +
      '<div><label>نوع الخدمة</label><select name="sub">' + subs.map(function (s) { return '<option>' + esc(s) + '</option>'; }).join('') + '</select></div>' +
      '<div><label>عنوان الخدمة</label><input name="title" required maxlength="60" placeholder="مثلاً: تصميم Miniature لفيديوهاتك"></div>' +
      '<div><label>المدينة</label><input name="city" required maxlength="30"></div>' +
      '<div><label>الحي / الدوار (باش يلقاك الأقرب ليك)</label><input name="area" maxlength="40"></div>' +
      
      '<div><label>رقم الواتساب</label><input name="phone" dir="ltr" required inputmode="tel" placeholder="2126XXXXXXXX"></div>' +
      '<div><label>الثمن بالدرهم (اتركو خاوي = حسب الاتفاق)</label><input name="price" type="number" min="0" step="1" inputmode="numeric" placeholder="مثلاً: 30"></div>' +
      '<div><label>وصف قصير</label><textarea name="desc" rows="3" required maxlength="240"></textarea></div>' +
      '<button class="sv-cta" type="submit"><i class="fa-solid fa-paper-plane"></i> ' + (session() ? 'انشر الخدمة' : 'إرسال للمراجعة (واتساب)') + '</button>' +
      '<button type="button" class="sv-chip" id="sv-back">رجوع</button>' +
      '<p class="sv-note">' + (session() ? 'الخدمة كتتنشر مباشرة فحسابك، وتقدر تتقبل طلبات بضمان m1li.' : 'سجّل الدخول باش تنشر مباشرة وتقبل طلبات بضمان، ولا ابعت الطلب لفريق m1li عبر واتساب.') + '</p></form>';
  }

  function orderService(lid) {
    if (!session()) { alert('سجّل الدخول (مركز المطورين) باش تطلب بضمان m1li.'); switchTab('developer'); return; }
    if (!window.M1LI_ORDERS) { alert('نظام الطلبات ما محمّلش.'); return; }
    var it = S.items.filter(function (x) { return x.lid === lid; })[0]; if (!it) return;
    var amount = it.priceNum;
    if (!(amount > 0)) { amount = Number(prompt('الثمن المتفق عليه مع صاحب الخدمة (بالدرهم):')); if (!(amount > 0)) return; }
    var brief = prompt('شنو بغيتي بالضبط؟ (وصف قصير للطلب)', '') || '';
    M1LI_ORDERS.create(lid, { amount: amount, brief: brief }).then(function (r) {
      if (!r || !r.ok) { alert(errMsg(r)); return; }
      alert('تسجل الطلب ✅\nحوّل ' + r.amount + ' درهم ل m1li' + (r.payInfo ? ': ' + r.payInfo : '') + '\nكتب فالمرجع: ' + r.payCode + '\nالفلوس كتبقى محجوزة حتى تستلم الخدمة.');
      if (typeof openAccount === 'function') openAccount('orders');
    });
  }

  /* مدة التسليم كتكون فالوصف بصيغة "(مدة التسليم: X)": كنفصلوها فشارة خاصة، و"includes" حقل اختياري (شنو كياخد الكليان) */
  function deliveryParts(desc, includes) {
    var m = /\s*[\(（]\s*مدة التسليم\s*[:：]\s*([^\)）]+)[\)）]\s*/.exec(desc || ''), clean = m ? desc.replace(m[0], ' ').trim() : (desc || '');
    return '<p>' + esc(clean) + '</p>' +
      (includes ? '<p class="sv-inc">يشمل: ' + esc(includes) + '</p>' : '') +
      (m ? '<div class="sv-eta">⏱ التسليم: ' + esc(m[1].trim()) + '</div>' : '');
  }
  function render(form) {
    var v = $('view-services'); if (!v) return;
    var h = '<div class="sv-hero"><h2><i class="fa-solid fa-handshake-angle"></i> خدمات m1li</h2><p>خدمات مصغرة، حرفيون، وأرباح — كلشي فبلاصة وحدة.</p></div>' +
      '<div class="sv-seg">' + Object.keys(CATS).map(function (k) {
        return '<button type="button" data-cat="' + k + '" class="' + (S.cat === k ? 'on' : '') + '"><i class="fa-solid ' + CATS[k].icon + '"></i>' + CATS[k].label + '</button>';
      }).join('') + '</div><div id="sv-body" class="space-y-4">' + (S.cat === 'earn' ? earnCards() : (form ? formHtml() : listHtml())) + '</div>';
    v.innerHTML = h;
    v.querySelectorAll('[data-cat]').forEach(function (b) { b.onclick = function () { S.cat = b.dataset.cat; S.sub = ''; S.q = ''; S.city = ''; render(); }; });
    v.querySelectorAll('[data-sub]').forEach(function (b) { b.onclick = function () { S.sub = b.dataset.sub; render(); }; });
    var q = $('sv-q'); if (q) q.oninput = function () { S.q = q.value; var p = q.selectionStart; render(); var n = $('sv-q'); n.focus(); n.setSelectionRange(p, p); };
    var ci = $('sv-city'); if (ci) ci.onchange = function () { S.city = ci.value; render(); };
    var add = $('sv-add'); if (add) add.onclick = function () { render(true); window.scrollTo({ top: 0, behavior: 'smooth' }); };
    v.querySelectorAll('[data-share]').forEach(function (b) { b.onclick = function () { window.svShare(b.dataset.share, b.dataset.st); }; });
    v.querySelectorAll('[data-order]').forEach(function (b) { b.onclick = function () { orderService(b.dataset.order); }; });
    var bk = $('sv-back'); if (bk) bk.onclick = function () { render(); };
    var f = $('sv-form'); if (f) f.onsubmit = function (e) {
      e.preventDefault();
      var d = {}; new FormData(f).forEach(function (val, k) { d[k] = String(val).trim(); });
      d.phone = digits(d.phone);
      if (d.phone.length < 9) { alert('رقم الواتساب ما بانش صحيح'); return; }
      d.cat = S.cat;
      if (session()) {
        var btn = f.querySelector('button[type=submit]'); if (btn) btn.disabled = true;
        api('POST', '/api/listings', { kind: 'service', svcat: d.cat, sub: d.sub, title: d.title, desc: d.desc, price: d.price ? Number(d.price) : 0, city: d.city, area: d.area, whatsapp: d.phone }).then(function (r) {
          if (btn) btn.disabled = false;
          if (!r || !r.ok) { alert(errMsg(r)); return; }
          alert('تنشرات خدمتك ✅'); S.loaded = false; load().then(function () { render(); });
        });
        return;
      }
      var sent = lsGet(); sent.push(d); lsSet(sent);
      var txt = 'طلب تسجيل خدمة فـ m1li\nالصنف: ' + CATS[d.cat].label + ' / ' + d.sub + '\nالعنوان: ' + d.title + '\nالاسم: ' + d.name + '\nالمدينة: ' + d.city + '\nالحي: ' + (d.area || '-') + 
        '\nالهاتف: ' + d.phone + '\nالثمن: ' + (d.price || '-') + '\nالوصف: ' + d.desc;
      var a = admin();
      if (!a || a === '212600000000') { alert('خاص صاحب الموقع يبدل رقم الواتساب فـ config.js باش توصل الطلبات.'); return; }
      window.open('https://wa.me/' + a + '?text=' + encodeURIComponent(txt), '_blank');
      render();
    };
  }

  window.renderServices = function () { load().then(function () { render(); }); };
})();
