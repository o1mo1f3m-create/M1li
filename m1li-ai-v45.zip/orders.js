/* m1li — شاشة «طلبات الخدمات» (Escrow يدوي): الزبون يدفع لـ m1li، m1li كتأكد وكتحجز، الفلوس كتتحرر ملي الزبون يقبل.
   كتخدم مع مسارات /api/service-orders/* و /api/services/config فالسيرفر. */
(function () {
  var API = String(window.M1LI_API || '').replace(/\/+$/, '');
  var CFG = null;
  function session() { try { var s = JSON.parse(localStorage.getItem('m1li_session') || 'null'); return s && s.token ? s : null; } catch (e) { return null; } }
  function call(method, path, body) {
    var s = session(); if (!API || !s) return Promise.resolve({ ok: false, error: 'unauthorized' });
    var h = { 'Authorization': 'Bearer ' + s.token }; if (body) h['Content-Type'] = 'application/json';
    return fetch(API + path, { method: method, headers: h, cache: 'no-store', body: body ? JSON.stringify(body) : undefined })
      .then(function (r) { return r.json().catch(function () { return { ok: false, error: 'network' }; }); })
      .catch(function () { return { ok: false, error: 'network' }; });
  }
  function config() {
    if (CFG) return Promise.resolve(CFG);
    return fetch(API + '/api/services/config', { cache: 'no-store' }).then(function (r) { return r.json(); })
      .then(function (j) { CFG = j && j.ok ? j : {}; return CFG; }).catch(function () { return {}; });
  }
  var ERR = {
    unauthorized: 'سجّل الدخول من جديد.', forbidden: 'ماشي طلبك.', bad_state: 'حالة الطلب تبدلات، حدّث الصفحة.',
    bad_pay_ref: 'كتب مرجع التحويل (3 حروف على الأقل).', bad_note: 'كتب سبب النزاع (5 حروف على الأقل).',
    not_found: 'الطلب ما بقاش موجود.', rate_limited: 'محاولات كثيرة، جرّب من بعد.', too_many_open_orders: 'عندك طلبات بزاف فانتظار الدفع.',
    bad_amount: 'المبلغ خارج الحدود المسموحة.', own_service: 'ما يمكنش تطلب خدمتك.', services_table_missing: 'نظام الخدمات ما مفعّلش فالسيرفر بعد.', network: 'ما كاينش اتصال بالسيرفر.'
  };
  function el(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }
  function mad(n) { return (Math.round(Number(n || 0) * 100) / 100).toLocaleString('en-US') + ' MAD'; }
  function dt(ms) { try { return new Date(ms).toLocaleString(); } catch (e) { return ''; } }
  function left(ms) { var h = Math.max(0, Math.ceil((ms - Date.now()) / 3600000)); return h >= 24 ? Math.ceil(h / 24) + ' يوم' : h + ' ساعة'; }
  var STATUS = {
    awaiting_payment: ['⏳', 'فانتظار الدفع'], funded: ['🔒', 'الفلوس محجوزة عند m1li'], delivered: ['📦', 'تسلّمات الخدمة'],
    completed: ['✅', 'مكتمل'], disputed: ['⚠️', 'نزاع (مراجعة m1li)'], refunded: ['↩️', 'مسترجع للزبون'], cancelled: ['✖️', 'ملغى']
  };

  function btn(label, cls, fn) { var b = el('button', cls || 'acc-btn-sm', label); b.type = 'button'; b.onclick = fn; return b; }
  function act(box, path, body, okMsg) {
    return function () {
      var msg = box.querySelector('.ord-msg'); if (msg) msg.textContent = '…';
      call('POST', path, body ? body() : {}).then(function (r) {
        if (!r || !r.ok) { var m = box.querySelector('.ord-msg'); if (m) m.textContent = ERR[r && r.error] || 'وقع مشكل، عاود المحاولة.'; return; }
        paint(box.closest('#acc-panel-orders') || box.parentNode);
      });
    };
  }

  function card(o, c) {
    var st = STATUS[o.status] || ['•', o.status], buyer = o.role === 'buyer';
    var box = el('div', 'acc-row'); box.style.cssText = 'display:block;border:1px solid rgba(148,163,184,.25);border-radius:14px;padding:12px;margin:10px 0';
    var head = el('div'); head.style.cssText = 'display:flex;justify-content:space-between;gap:8px;align-items:center';
    head.appendChild(el('strong', null, '#' + o.id + ' · ' + o.title));
    head.appendChild(el('span', null, st[0] + ' ' + st[1]));
    box.appendChild(head);
    var meta = el('div', null, (buyer ? 'الشاب: ' : 'الزبون: ') + (o.other || '—') + ' · المبلغ: ' + mad(o.amount) + (buyer ? '' : ' · صافيك: ' + mad(o.net) + ' (عمولة m1li ' + mad(o.fee) + ')'));
    meta.style.cssText = 'font-size:13px;opacity:.85;margin:6px 0'; box.appendChild(meta);
    if (o.brief) { var b = el('div', null, '📝 ' + o.brief); b.style.cssText = 'font-size:13px;margin:4px 0'; box.appendChild(b); }
    if (o.note) { var n = el('div', null, '💬 ' + o.note); n.style.cssText = 'font-size:13px;margin:4px 0'; box.appendChild(n); }
    var acts = el('div'); acts.style.cssText = 'display:flex;gap:8px;flex-wrap:wrap;margin-top:8px';
    var base = '/api/service-orders/' + o.id;
    if (buyer && o.status === 'awaiting_payment') {
      var info = el('div', null, 'حوّل ' + mad(o.amount) + ' ل m1li' + (c.payInfo ? ': ' + c.payInfo : '') + ' وكتب فالمرجع/الملاحظة الكود: M1-' + o.id);
      info.style.cssText = 'font-size:13px;margin:6px 0;padding:8px;border-radius:10px;background:rgba(24,119,242,.12)'; box.appendChild(info);
      if (o.payRef) box.appendChild(el('div', null, '✔ المرجع لي صيفطتي: ' + o.payRef + ' — كنتسناو تأكيد m1li للفلوس.'));
      var inp = el('input'); inp.placeholder = 'مرجع التحويل (رقم/اسم المحوِّل)'; inp.maxLength = 80; inp.value = o.payRef || ''; inp.style.cssText = 'flex:1;min-width:160px;padding:8px;border-radius:10px;border:1px solid #475569;background:transparent;color:inherit';
      acts.appendChild(inp);
      acts.appendChild(btn('صيفطت الفلوس', 'acc-btn-main', act(box, base + '/paid', function () { return { payRef: inp.value.trim() }; })));
      acts.appendChild(btn('إلغاء الطلب', 'acc-btn-sm', function () { if (confirm('إلغاء هاد الطلب؟')) act(box, base + '/cancel')(); }));
    } else if (o.status === 'funded') {
      box.appendChild(el('div', null, buyer ? 'الفلوس عند m1li والشاب كيخدم. ما تتحرر ليه حتى تقبل.' : 'الفلوس محجوزة ✔ بدا الخدمة، ملي تسالي سلّم.'));
      if (!buyer) { var nt = el('input'); nt.placeholder = 'ملاحظة التسليم / رابط (اختياري)'; nt.maxLength = 300; nt.style.cssText = 'flex:1;min-width:160px;padding:8px;border-radius:10px;border:1px solid #475569;background:transparent;color:inherit'; acts.appendChild(nt);
        acts.appendChild(btn('سلّمت الخدمة', 'acc-btn-main', act(box, base + '/deliver', function () { return { note: nt.value.trim() }; }))); }
      else acts.appendChild(btn('فتح نزاع', 'acc-btn-sm', function () { var t = prompt('شنو المشكل؟ (5 حروف على الأقل)'); if (t) act(box, base + '/dispute', function () { return { note: t }; })(); }));
    } else if (o.status === 'delivered') {
      if (buyer) {
        box.appendChild(el('div', null, 'الشاب سلّم. إلا ما ردّيتي حتى ' + (o.releaseAt ? left(o.releaseAt) : 'مدة التحرير') + ' غادي تتحرر الفلوس للشاب وحدها.'));
        acts.appendChild(btn('قبول وتحرير الفلوس', 'acc-btn-main', function () { if (confirm('تأكيد: الخدمة وصلات وتتحرر الفلوس للشاب؟')) act(box, base + '/accept')(); }));
        acts.appendChild(btn('فتح نزاع', 'acc-btn-sm', function () { var t = prompt('شنو المشكل؟ (5 حروف على الأقل)'); if (t) act(box, base + '/dispute', function () { return { note: t }; })(); }));
      } else box.appendChild(el('div', null, 'كنتسناو قبول الزبون' + (o.releaseAt ? ' (تحرير تلقائي بعد ' + left(o.releaseAt) + ')' : '') + '.'));
    } else if (o.status === 'disputed') box.appendChild(el('div', null, 'الطلب عند m1li للمراجعة. غادي نتواصلو معاك.'));
    else if (o.status === 'completed') box.appendChild(el('div', null, buyer ? 'تم. شكراً!' : 'تحرّرات الفلوس لرصيدك (النقاط) — تقدر تسحبها من «رصيدي».'));
    if (acts.childNodes.length) box.appendChild(acts);
    box.appendChild(el('div', 'ord-msg')).style.cssText = 'font-size:12px;color:#f87171;margin-top:6px;min-height:14px';
    var d = el('div', null, 'تسجل: ' + dt(o.created)); d.style.cssText = 'font-size:11px;opacity:.6;margin-top:2px'; box.appendChild(d);
    return box;
  }

  function paint(panel) {
    panel = panel || document.getElementById('acc-panel-orders'); if (!panel) return;
    panel.textContent = '';
    if (!session() || !API) {
      var e = el('div', 'acc-empty'); e.appendChild(el('div', null, 'سجّل الدخول باش تشوف طلبات الخدمات ديالك.'));
      var b = btn('تسجيل الدخول / إنشاء حساب', 'acc-btn-main', function () { if (window.switchTab) switchTab('developer'); }); b.style.marginTop = '14px'; e.appendChild(b); panel.appendChild(e); return;
    }
    panel.appendChild(el('div', 'acc-row', 'جاري التحميل…'));
    Promise.all([config(), call('GET', '/api/service-orders/mine')]).then(function (res) {
      var c = res[0] || {}, r = res[1]; panel.textContent = '';
      var note = el('div', null, 'كيفاش كتخدم الحماية: كتحوّل الفلوس ل m1li، m1li كتأكد وكتحجزها، ما كتتحررش للشاب حتى تقبل الخدمة' + (c.autoReleaseHours ? ' (ولا تنتظر ' + c.autoReleaseHours + ' ساعة بعد التسليم)' : '') + '. فحالة نزاع كتراجع m1li الطلب يدوياً.');
      note.style.cssText = 'font-size:12px;opacity:.75;margin-bottom:6px'; panel.appendChild(note);
      if (!r || !r.ok) { panel.appendChild(el('div', 'acc-empty', ERR[r && r.error] || 'تعذّر تحميل الطلبات.')); return; }
      if (!r.items.length) { panel.appendChild(el('div', 'acc-empty', 'ما عندك حتى طلب خدمة دابا.')); return; }
      r.items.forEach(function (o) { panel.appendChild(card(o, c)); });
    });
  }

  /* باش تستعملها واجهة الخدمات ملي تكون: M1LI_ORDERS.create(listingId, {amount, brief}) */
  function create(listingId, opts) {
    opts = opts || {};
    return call('POST', '/api/service-orders', { listingId: listingId, amount: opts.amount, brief: opts.brief || '', ref: window.M1LI_REF ? window.M1LI_REF() : '' });
  }
  window.M1LI_ORDERS = { paint: paint, create: create };
})();
