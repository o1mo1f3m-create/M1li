/* ===== إعدادات m1li — المكان الوحيد اللي تعدّل فيه ===== */
// عنوان السيرفر (نفس العنوان كيستعملو المتجر ولوحات الإدارة)
window.M1LI_API = 'https://m1li-production.up.railway.app';
// رقم الواتساب ديال التاجر بصيغة دولية بلا + ولا أصفار، مثال: 212612345678
// تم ضبط الرقم.
window.M1LI_WHATSAPP = '212600247294';

// ===== أرباح AdSense (كتبقى معطّلة حتى تعمّر الجوج) =====
// من حسابك فـ AdSense: Publisher ID (كيبدا بـ ca-pub-) و رقم وحدة إعلان (ad slot) من Ads → By ad unit
window.M1LI_ADSENSE_CLIENT = '';
window.M1LI_ADSENSE_SLOT = '';

// ===== Amazon Associates: Store ID ديالك (كيتزاد تلقائياً فكل رابط أمازون) =====
window.M1LI_AMAZON_TAG = 'm1li-20';
