/* ============================================================
   إعلان AdSense واحد فصفحة المتجر. كيتفعّل غير إلا عمّرتي M1LI_ADSENSE_CLIENT و M1LI_ADSENSE_SLOT فـ config.js.
   ⚠️ ممنوع تطلب من الزبناء/الناشرين يضغطو على الإعلانات — هادشي كيسدّ ليك حساب AdSense.
   ============================================================ */
(function () {
  var client = String(window.M1LI_ADSENSE_CLIENT || '').trim(), slot = String(window.M1LI_ADSENSE_SLOT || '').trim();
  if (!/^ca-pub-\d{10,20}$/.test(client) || !/^\d{6,20}$/.test(slot)) return;
  var box = document.getElementById('m1li-ad'); if (!box) return;
  var label = document.createElement('div'); label.textContent = 'إعلان'; label.style.cssText = 'font-size:10px;color:#64748b;text-align:center;margin-bottom:4px';
  var ins = document.createElement('ins'); ins.className = 'adsbygoogle'; ins.style.display = 'block';
  ins.setAttribute('data-ad-client', client); ins.setAttribute('data-ad-slot', slot);
  ins.setAttribute('data-ad-format', 'auto'); ins.setAttribute('data-full-width-responsive', 'true');
  box.appendChild(label); box.appendChild(ins);
  var sc = document.createElement('script'); sc.async = true; sc.crossOrigin = 'anonymous';
  sc.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' + encodeURIComponent(client);
  sc.onload = function () { try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch (e) { /* ignore */ } };
  document.head.appendChild(sc);
})();
