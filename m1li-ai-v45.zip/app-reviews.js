/* مراجعات حقيقية للتطبيقات — كتتصل بـ /api/reviews (انظر server-docs/REVIEWS-SPEC.md) */
(function () {
  var stars = 5;
  function E(s) { var d = document.createElement('div'); d.textContent = s == null ? '' : s; return d.innerHTML; }
  function $(id) { return document.getElementById(id); }
  function T(m) { if (typeof toast === 'function') toast(m); }
  function sheet() {
    var s = $('rv-sheet');
    if (s) return s;
    s = document.createElement('div');
    s.id = 'rv-sheet';
    s.style.cssText = 'position:fixed;inset:0;z-index:70;display:none;background:rgba(0,0,0,.6);align-items:flex-end;justify-content:center';
    s.innerHTML = '<div style="background:#0f172a;color:#e2e8f0;width:100%;max-width:560px;max-height:80vh;overflow:auto;border-radius:18px 18px 0 0;padding:16px;border:1px solid #334155">' +
      '<div style="display:flex;justify-content:space-between;align-items:center"><b>💬 مراجعات التطبيق</b><button type="button" id="rv-close" aria-label="سدّ" style="font-size:20px;color:#94a3b8">✕</button></div>' +
      '<div id="rv-sum" style="font-size:12px;color:#94a3b8;margin:6px 0"></div><div id="rv-list"></div>' +
      '<div id="rv-form" style="margin-top:12px;border-top:1px solid #334155;padding-top:10px"></div></div>';
    document.body.appendChild(s);
    s.addEventListener('click', function (e) { if (e.target === s || e.target.id === 'rv-close') s.style.display = 'none'; });
    return s;
  }
  function form(appId) {
    var f = $('rv-form'), ses = window.M1Views && M1Views.session && M1Views.session();
    if (!ses) { f.innerHTML = '<p style="font-size:12px;color:#94a3b8">سجّل الدخول (حساب m1li) باش تكتب مراجعة.</p>'; return; }
    var st = '';
    for (var i = 1; i <= 5; i++) st += '<button type="button" data-s="' + i + '" style="font-size:22px;color:' + (i <= stars ? '#fbbf24' : '#475569') + '">★</button>';
    f.innerHTML = '<div id="rv-st">' + st + '</div>' +
      '<textarea id="rv-txt" maxlength="300" rows="3" placeholder="شنو بان ليك فهاد التطبيق؟ (اختياري، 300 حرف)" style="width:100%;margin:6px 0;padding:8px;border-radius:10px;background:#1e293b;color:#e2e8f0;border:1px solid #334155;font-size:13px"></textarea>' +
      '<button type="button" id="rv-send" style="background:#6366f1;color:#fff;border-radius:10px;padding:8px 16px;font-size:13px">نشر المراجعة</button>';
    $('rv-st').onclick = function (e) { var n = e.target.getAttribute && +e.target.getAttribute('data-s'); if (n) { stars = n; form(appId); } };
    $('rv-send').onclick = function () {
      var b = this; b.disabled = true;
      M1Views.review(appId, stars, $('rv-txt').value.trim()).then(function (r) {
        b.disabled = false;
        if (r.ok) { T('شكراً على المراجعة ⭐'); load(appId); }
        else T(r.error === 'unauthorized' ? 'خاصك تسجل الدخول من جديد' : r.error === 'rate_limited' ? 'مراجعات بزاف، جرّب من بعد' : 'تعذّر نشر المراجعة دابا');
      });
    };
  }
  function load(appId) {
    $('rv-list').innerHTML = '<p style="font-size:12px;color:#94a3b8">كنحمّلو...</p>';
    M1Views.reviews(appId).then(function (j) {
      if (!j) { $('rv-sum').textContent = ''; $('rv-list').innerHTML = '<p style="font-size:12px;color:#94a3b8">المراجعات غير متاحة دابا.</p>'; $('rv-form').innerHTML = ''; return; }
      $('rv-sum').textContent = j.count ? '⭐ ' + j.avg + ' · ' + j.count + ' مراجعة' : 'ما كاين حتى مراجعة، كون الأول!';
      $('rv-list').innerHTML = (j.reviews || []).map(function (r) {
        return '<div style="border-bottom:1px solid #1e293b;padding:8px 0"><b style="font-size:13px">' + E(r.name || 'مستخدم') + '</b> <span style="color:#fbbf24;font-size:12px">' + '★'.repeat(Math.max(0, Math.min(5, r.stars | 0))) + '</span>' +
          (r.body ? '<p style="margin:2px 0 0;font-size:13px;color:#cbd5e1">' + E(r.body) + '</p>' : '') + '</div>';
      }).join('');
      form(appId);
    });
  }
  window.openAppReviews = function () {
    var id = window.state && state.current;
    if (!id || id === '__preview__') return;
    sheet().style.display = 'flex';
    load(id);
  };
})();
