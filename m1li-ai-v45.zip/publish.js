/* ============================================================
   m1li — صفحة «نشر» (داخل حسابي): تطبيق (3 مراحل) · كتاب · منتج (دفع عند الاستلام)
   + عرض الكتب في الرئيسية وصفحة الكتب + قوائم «كتبي/منتجاتي» في الحساب.
   يعتمد على: index.html (switchTab, toast, esc, hSession, openApp…) و m1li-views.js و shop.js
   ============================================================ */
(function () {
  'use strict';

  var INPUT = 'w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm focus:border-brand-500 focus:outline-none';
  var CITIES = ['الدار البيضاء', 'الرباط', 'سلا', 'تمارة', 'مراكش', 'فاس', 'مكناس', 'طنجة', 'تطوان', 'أكادير', 'وجدة', 'القنيطرة', 'المحمدية', 'الجديدة', 'آسفي', 'بني ملال', 'خريبكة', 'الناظور', 'تازة', 'العيون'];
  var ERR = {
    unauthorized: 'انتهت جلستك. سجّل الدخول من جديد.', phone_unverified: 'أكّد رقم هاتفك أولاً من «مركز المطورين» ثم انشر.',
    network: 'تعذّر الاتصال بالسيرفر. تأكد من الإنترنت وحاول مرة أخرى.', rate_limited: 'نشرتي بزاف فهاد الساعة. عاود حاول من بعد.',
    too_large: 'الملف كبير بزاف.', bad_file_type: 'نوع الملف غير مدعوم.', not_zip: 'الملف تالف أو ماشي ZIP صالح.', not_image: 'الصورة غير صالحة (JPG / PNG / WebP).',
    not_pdf: 'الملف ماشي PDF صالح.', bad_title: 'الاسم قصير بزاف.', bad_category: 'التصنيف غير صالح.', bad_apk: 'ملف ZIP غير موجود على السيرفر. عاود الرفع.',
    bad_image: 'خاص صورة وحدة على الأقل.', bad_price: 'الثمن غير صالح.', bad_city: 'دخل اسم المدينة.', bad_whatsapp: 'رقم واتساب غير صالح (مثال: 0612345678).',
    bad_file: 'ملف PDF غير موجود على السيرفر. عاود الرفع.', too_many_apps: 'وصلتي الحد الأقصى ديال التطبيقات (30).', too_many_listings: 'وصلتي الحد الأقصى ديال المنشورات (60).',
    zip_rejected: 'الفحص الآلي رفض الملف.', zip_unsupported: 'صيغة ZIP غير مدعومة (استعمل ZIP عادي).', zip_encrypted: 'الأرشيف محمي بكلمة سر.',
    zip_too_many_files: 'عدد الملفات كبير بزاف (الحد 3000).', zip_too_large: 'حجم الملفات بعد فك الضغط كبير بزاف.', forbidden: 'ماعندكش صلاحية.', not_found: 'غير موجود.',
    ai_disabled: 'الكتابة بالذكاء الاصطناعي غير مفعّلة دابا.', ai_rate_limited: 'استعملتي الميزة بزاف. عاود من بعد شوية.', ai_daily_limit: 'الميزة وصلات الحد اليومي. عاود غدا.', ai_failed: 'ما قدرتش نكتب الوصف دابا. عاود حاول.', ai_timeout: 'تأخّر الجواب. عاود حاول.',
    server_error: 'خطأ من السيرفر. عاود بعد شوية.', length_required: 'تعذّر تحديد حجم الملف.'
  };
  function errText(code) { return ERR[code] || ('تعذّر النشر' + (code && code !== 'network' ? ' (' + code + ')' : '') + '. عاود حاول.'); }

  var PUB = {
    tab: 'app',
    step: 1,
    app: { title: '', category: 'tools', desc: '', images: [], zip: null, busy: false, result: null },
    book: { title: '', author: '', desc: '', cover: null, pdf: null, busy: false },
    product: { title: '', city: '', price: '', whatsapp: '', desc: '', images: [], busy: false }
  };
  var LISTINGS = { book: [], product: [] };
  try { LISTINGS.book = JSON.parse(localStorage.getItem('m1li_books') || '[]'); LISTINGS.product = JSON.parse(localStorage.getItem('m1li_uprods') || '[]'); } catch (e) {}
  function $(id) { return document.getElementById(id); }
  function logged() { return !!(window.hSession && hSession()); }
  function fmtSize(n) { return n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB'; }
  function jsq(s) { return String(s).replace(/\\/g, '\\\\').replace(/'/g, "\\'"); }

  /* ---------------- الصور: تصغير قبل الرفع ---------------- */
  function prepImage(file) {
    return new Promise(function (resolve) {
      if (!file || !/^image\//.test(file.type)) return resolve(null);
      var url = URL.createObjectURL(file), img = new Image();
      img.onload = function () {
        var w = img.naturalWidth, h = img.naturalHeight, k = Math.min(1, 1280 / Math.max(w, h));
        var c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w * k)); c.height = Math.max(1, Math.round(h * k));
        var x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(img, 0, 0, c.width, c.height);
        c.toBlob(function (b) {
          URL.revokeObjectURL(url);
          if (!b) return resolve(null);
          resolve({ file: new File([b], 'img.jpg', { type: 'image/jpeg' }), preview: URL.createObjectURL(b) });
        }, 'image/jpeg', 0.85);
      };
      img.onerror = function () { URL.revokeObjectURL(url); resolve(null); };
      img.src = url;
    });
  }
  function addImages(list, files, max) {
    var arr = Array.prototype.slice.call(files || []).slice(0, Math.max(0, max - list.length));
    if (!arr.length) { toast('الحد الأقصى ' + max + ' صور'); return Promise.resolve(); }
    return Promise.all(arr.map(prepImage)).then(function (res) {
      var bad = 0; res.forEach(function (r) { if (r) list.push(r); else bad++; });
      if (bad) toast('بعض الملفات ماشي صور صالحة');
    });
  }
  function dropImage(list, i) { var r = list.splice(i, 1)[0]; if (r && r.preview) URL.revokeObjectURL(r.preview); }

  /* ---------------- رفع متسلسل مع نسبة التقدم ---------------- */
  function setProg(text, pct) {
    var t = $('pub-prog-text'), b = $('pub-prog-bar');
    if (t) t.textContent = text;
    if (b) { b.style.width = (pct == null ? 100 : pct) + '%'; b.classList.toggle('ind', pct == null); }
  }
  function uploadOne(file, label) {
    setProg(label + ' 0%', 0);
    return M1Views.uploadFile(file, function (p) { setProg(label + ' ' + p + '%', p); });
  }
  function uploadMany(items, label) {   // -> Promise<{ok, urls}|{ok:false,error}>
    var urls = [], i = 0;
    return new Promise(function (resolve) {
      (function next() {
        if (i >= items.length) return resolve({ ok: true, urls: urls });
        var lbl = items.length > 1 ? label + ' (' + (i + 1) + '/' + items.length + ')' : label;
        uploadOne(items[i].file || items[i], lbl).then(function (r) {
          if (!r.ok) return resolve({ ok: false, error: r.error });
          urls.push(r.url); i++; next();
        });
      })();
    });
  }
  function busyHTML(title) {
    return '<div class="pb-busy"><div class="pb-spin"></div><b>' + esc(title) + '</b><div class="pb-bar"><i id="pub-prog-bar"></i></div><small id="pub-prog-text">…</small>' +
      '<small class="pb-hint">ما تغلقش الصفحة حتى يكمل.</small></div>';
  }

  /* ---------------- واجهة صفحة النشر ---------------- */
  function field(label, inner, hint) {
    return '<div class="pb-f"><label>' + label + '</label>' + inner + (hint ? '<small>' + hint + '</small>' : '') + '</div>';
  }
  function val(v) { return esc(v == null ? '' : String(v)); }
  function inp(k, o) {
    o = o || {};
    return '<input type="' + (o.type || 'text') + '" data-k="' + k + '" value="' + val(PUB[PUB.tab][k]) + '" class="' + INPUT + '"' + (o.dir ? ' dir="' + o.dir + '"' : '') +
      (o.max ? ' maxlength="' + o.max + '"' : '') + (o.ph ? ' placeholder="' + esc(o.ph) + '"' : '') + (o.list ? ' list="' + o.list + '"' : '') + (o.mode ? ' inputmode="' + o.mode + '"' : '') + '>';
  }
  function imgPicker(id, list, max, hint) {
    var cells = list.map(function (im, i) {
      return '<div class="pb-img"><img src="' + im.preview + '" alt="">' + (i === 0 ? '<span>' + hint + '</span>' : '') +
        '<button type="button" onclick="pubDropImg(\'' + id + '\',' + i + ')" aria-label="حذف">×</button></div>';
    }).join('');
    var add = list.length < max ? '<label class="pb-img pb-add" for="pub-file-' + id + '"><i class="fa-solid fa-camera"></i><b>إضافة صورة</b><small>' + list.length + '/' + max + '</small></label>' : '';
    return '<div class="pb-imgs">' + cells + add + '</div>' +
      '<input type="file" id="pub-file-' + id + '" data-pick="' + id + '" accept="image/*"' + (max > 1 ? ' multiple' : '') + ' style="position:absolute;width:1px;height:1px;opacity:0">';
  }
  function filePicker(id, label, accept, file, icon) {
    return '<label for="pub-file-' + id + '" class="pb-file' + (file ? ' has' : '') + '"><i class="fa-solid ' + (file ? 'fa-circle-check' : icon) + '"></i>' +
      '<span><b>' + (file ? esc(file.name) : label) + '</b><small>' + (file ? fmtSize(file.size) + ' — اضغط للتغيير' : 'اضغط لاختيار الملف') + '</small></span></label>' +
      '<input type="file" id="pub-file-' + id + '" data-pick="' + id + '" accept="' + accept + '" style="position:absolute;width:1px;height:1px;opacity:0">';
  }
  function errBox() { return '<p id="pub-err" class="pb-err hidden"></p>'; }
  function showErr(msg) { var e = $('pub-err'); if (!e) { toast(msg); return; } e.textContent = msg; e.classList.remove('hidden'); e.scrollIntoView({ behavior: 'smooth', block: 'center' }); }

  function renderApp() {
    var A = PUB.app, st = PUB.step;
    if (A.busy) return busyHTML('جاري نشر تطبيقك…');
    if (A.result) return renderAppResult(A.result);
    var steps = ['اسم التطبيق', 'صور التطبيق', 'ملف ZIP'];
    var head = '<ol class="pb-steps">' + steps.map(function (t, i) {
      var n = i + 1; return '<li class="' + (n < st ? 'done' : n === st ? 'on' : '') + '"><span>' + (n < st ? '<i class="fa-solid fa-check"></i>' : n) + '</span><em>' + t + '</em></li>';
    }).join('') + '</ol>';
    var body = '';
    if (st === 1) {
      body = field('اسم التطبيق / اللعبة *', inp('title', { max: 60, ph: 'مثال: لعبة الأفعى' })) +
        field('الفئة', '<select data-k="category" class="' + INPUT + '">' + [['games', 'ألعاب'], ['tools', 'أدوات'], ['productivity', 'إنتاجية'], ['lifestyle', 'أسلوب حياة']].map(function (c) {
          return '<option value="' + c[0] + '"' + (A.category === c[0] ? ' selected' : '') + '>' + c[1] + '</option>'; }).join('') + '</select>') +
        field('وصف مختصر (اختياري)', '<textarea data-k="desc" rows="3" maxlength="300" class="' + INPUT + '" placeholder="شنو كيدير تطبيقك؟">' + val(A.desc) + '</textarea>') +
        errBox() + '<div class="pb-nav"><button type="button" class="acc-btn-main" onclick="pubNext()">التالي <i class="fa-solid fa-angle-left"></i></button></div>';
    } else if (st === 2) {
      body = field('صور التطبيق * (حتى 5)', imgPicker('app', A.images, 5, 'الأيقونة'), 'الصورة الأولى كتولي أيقونة التطبيق. كتتصغّر أوتوماتيكياً قبل الرفع.') +
        errBox() + '<div class="pb-nav"><button type="button" class="acc-btn-sm" onclick="pubBack()"><i class="fa-solid fa-angle-right ml-1"></i> رجوع</button>' +
        '<button type="button" class="acc-btn-main" onclick="pubNext()">التالي <i class="fa-solid fa-angle-left"></i></button></div>';
    } else {
      body = field('ملف التطبيق (ZIP) *', filePicker('zip', 'اختر ملف ZIP', '.zip,.apk', A.zip, 'fa-file-zipper'),
          'ضع index.html فالجذر (أو فمجلد واحد). الحد الأقصى 60MB. بعد الضغط على «نشر» كيتفحص الملف أوتوماتيكياً، وإلى كان تطبيق ويب كيتنشر وكيخدم مباشرة.') +
        errBox() + '<div class="pb-nav"><button type="button" class="acc-btn-sm" onclick="pubBack()"><i class="fa-solid fa-angle-right ml-1"></i> رجوع</button>' +
        '<button type="button" class="pb-publish" onclick="pubPublishApp()"><i class="fa-solid fa-paper-plane"></i> نشر</button></div>';
    }
    return head + '<div class="pb-form">' + body + '</div>';
  }

  function issueHTML(i) {
    var cls = i.level === 'high' ? 'hi' : i.level === 'medium' ? 'md' : 'lo', ic = i.level === 'high' ? 'fa-circle-xmark' : i.level === 'medium' ? 'fa-triangle-exclamation' : 'fa-circle-info';
    return '<li class="' + cls + '"><i class="fa-solid ' + ic + '"></i><span>' + esc(i.msg) + '</span></li>';
  }
  function renderAppResult(R) {
    var rep = R.report || {}, issues = (rep.issues || []), notes = (rep.notes || []);
    var details = (rep.kind === 'web' ? '<div class="pb-chips"><span>تطبيق ويب</span><span>' + (rep.fileCount || 0) + ' ملف</span><span>' + fmtSize(rep.totalBytes || 0) + '</span><span dir="ltr">' + esc(rep.entry || '') + '</span></div>' : '') +
      (notes.length ? '<ul class="pb-issues">' + notes.map(function (n) { return issueHTML({ level: 'low', msg: n }); }).join('') + '</ul>' : '') +
      (issues.length ? '<ul class="pb-issues">' + issues.map(issueHTML).join('') + '</ul>' : '');
    if (R.ok) {
      var web = rep.kind === 'web';
      var msg = web ? (R.live ? 'اجتاز الفحص الآلي ✓ — التطبيق خدّام وظاهر لجميع الزوار الآن.' : 'اجتاز الفحص الآلي مع ملاحظات — غادي يظهر للجميع بعد المراجعة (ساعة تقريباً)، وانت كتشوفو دابا فـ«تطبيقاتي».')
        : 'تم استلام الملف. هاد النوع كيتنشر للتحميل فقط ولا كيخدمش فالمتصفح.';
      return '<div class="pb-res ok"><div class="pb-res-ico"><i class="fa-solid fa-circle-check"></i></div><h3>تم نشر تطبيقك 🎉</h3><p>' + msg + '</p>' + details +
        '<div class="pb-nav center">' + (web ? '<button type="button" class="pb-publish" onclick="pubPlay(\'' + jsq(R.id) + '\')"><i class="fa-solid fa-play"></i> تشغيل التطبيق</button>' : '') +
        '<button type="button" class="acc-btn-sm" onclick="openAccount(\'apps\')">تطبيقاتي</button><button type="button" class="acc-btn-sm" onclick="pubReset(\'app\')">نشر تطبيق آخر</button></div></div>';
    }
    return '<div class="pb-res bad"><div class="pb-res-ico"><i class="fa-solid fa-circle-xmark"></i></div><h3>ما قدرناش ننشرو التطبيق</h3><p>' + esc(R.msg || errText(R.error)) + '</p>' + details +
      '<div class="pb-nav center"><button type="button" class="acc-btn-main" onclick="pubRetryZip()">اختيار ملف آخر</button></div></div>';
  }

  function renderBook() {
    var B = PUB.book;
    if (B.busy) return busyHTML('جاري نشر الكتاب…');
    return '<div class="pb-form">' + field('عنوان الكتاب *', inp('title', { max: 100, ph: 'مثال: رياضيات السنة الثالثة' })) +
      field('المؤلف (اختياري)', inp('author', { max: 60 })) +
      field('وصف (اختياري)', '<textarea data-k="desc" rows="3" maxlength="600" class="' + INPUT + '">' + val(B.desc) + '</textarea>') +
      field('صورة الغلاف *', imgPicker('bookcover', B.cover ? [B.cover] : [], 1, 'الغلاف')) +
      field('ملف الكتاب (PDF) *', filePicker('bookpdf', 'اختر ملف PDF', '.pdf,application/pdf', B.pdf, 'fa-file-pdf'), 'الحد الأقصى 40MB. الكتب كتنشر مجانية للقراءة والتحميل.') +
      errBox() + '<div class="pb-nav"><button type="button" class="pb-publish" onclick="pubPublishBook()"><i class="fa-solid fa-paper-plane"></i> نشر الكتاب</button></div></div>';
  }
  /* ✨ كتابة الوصف بالذكاء الاصطناعي (عربية / Français / English) — كيحتاج تسجيل الدخول */
  function aiButtons() {
    return '<div class="flex flex-wrap items-center gap-2 mt-2 text-xs"><span class="text-slate-400">✨ اكتب لي الوصف:</span>' +
      [['ar', 'العربية'], ['fr', 'Français'], ['en', 'English']].map(function (l) {
        return '<button type="button" id="pub-ai-' + l[0] + '" onclick="pubAiDesc(\'' + l[0] + '\')" class="px-3 py-1 rounded-full border border-slate-600 text-slate-200">' + l[1] + '</button>';
      }).join('') + '</div>';
  }
  window.pubAiDesc = function (lang) {
    var P = PUB.product;
    if (!String(P.title || '').trim()) { toast('كتب اسم المنتج أولاً'); return; }
    if (needLogin()) return;
    if (P.aiBusy) return; P.aiBusy = true;
    var btn = $('pub-ai-' + lang); if (btn) btn.disabled = true; toast('كنكتب الوصف…');
    M1Views.aiDescribe(P.title.trim(), P.city || '', lang).then(function (r) {
      P.aiBusy = false;
      if (r && r.ok && r.desc) { P.desc = r.desc.slice(0, 600); renderPublish(); toast('تم ✨ تقدر تعدّل الوصف قبل النشر'); }
      else { if (btn) btn.disabled = false; afterAuthError(r && r.error); toast(errText(r && r.error)); }
    });
  };

  function renderProduct() {
    var P = PUB.product;
    if (P.busy) return busyHTML('جاري نشر المنتج…');
    return '<div class="pb-form"><div class="pb-cod"><i class="fa-solid fa-hand-holding-dollar"></i> الدفع عند الاستلام — الزبون كيتواصل معاك مباشرة فواتساب.</div>' +
      field('اسم المنتج *', inp('title', { max: 100, ph: 'مثال: حذاء رياضي' })) +
      '<div class="pb-row2">' + field('المدينة *', inp('city', { max: 40, list: 'pub-cities', ph: 'الدار البيضاء' })) +
      field('الثمن (د.م) *', inp('price', { type: 'number', dir: 'ltr', mode: 'decimal', ph: '199' })) + '</div>' +
      '<datalist id="pub-cities">' + CITIES.map(function (c) { return '<option value="' + c + '">'; }).join('') + '</datalist>' +
      field('رقم واتساب *', inp('whatsapp', { type: 'tel', dir: 'ltr', max: 25, mode: 'tel', ph: '06XXXXXXXX' })) +
      field('صور المنتج * (حتى 4)', imgPicker('product', P.images, 4, 'الرئيسية'), 'كتتصغّر أوتوماتيكياً قبل الرفع.') +
      field('وصف (اختياري)', '<textarea data-k="desc" rows="3" maxlength="600" class="' + INPUT + '">' + val(P.desc) + '</textarea>' + aiButtons()) +
      errBox() + '<div class="pb-nav"><button type="button" class="pb-publish" onclick="pubPublishProduct()"><i class="fa-solid fa-paper-plane"></i> نشر المنتج</button></div></div>';
  }

  function renderPublish() {
    ['app', 'book', 'product'].forEach(function (k) { var b = $('pub-seg-' + k); if (b) b.classList.toggle('on', k === PUB.tab); });
    var box = $('pub-body'); if (!box) return;
    if (!logged()) {
      box.innerHTML = '<div class="acc-empty"><i class="fa-solid fa-lock"></i>سجّل الدخول باش تنشر.<div style="margin-top:14px"><button type="button" class="acc-btn-main" onclick="switchTab(\'developer\')">تسجيل الدخول / إنشاء حساب</button></div></div>';
      return;
    }
    box.innerHTML = PUB.tab === 'app' ? renderApp() : PUB.tab === 'book' ? renderBook() : renderProduct();
  }
  window.renderPublish = renderPublish;
  window.pubOpen = function (tab) {
    PUB.tab = tab;
    if (state && state.tab === 'publish') { renderPublish(); window.scrollTo({ top: 0, behavior: 'smooth' }); } else switchTab('publish');
  };
  window.pubReset = function (tab) {
    if (tab === 'app') { PUB.app.images.forEach(function (i) { URL.revokeObjectURL(i.preview); }); PUB.app = { title: '', category: 'tools', desc: '', images: [], zip: null, busy: false, result: null }; PUB.step = 1; }
    renderPublish();
  };
  window.pubRetryZip = function () { PUB.app.result = null; PUB.app.zip = null; PUB.step = 3; renderPublish(); };

  /* حفظ قيم الحقول + اختيار الملفات (تفويض أحداث) */
  document.addEventListener('input', function (e) {
    var k = e.target && e.target.getAttribute && e.target.getAttribute('data-k');
    if (k && $('pub-body') && $('pub-body').contains(e.target)) PUB[PUB.tab][k] = e.target.value;
  });
  document.addEventListener('change', function (e) {
    var t = e.target, id = t && t.getAttribute && t.getAttribute('data-pick');
    if (!id) {
      var k = t && t.getAttribute && t.getAttribute('data-k');
      if (k && $('pub-body') && $('pub-body').contains(t)) PUB[PUB.tab][k] = t.value;
      return;
    }
    var files = t.files; if (!files || !files.length) return;
    if (id === 'app') addImages(PUB.app.images, files, 5).then(renderPublish);
    else if (id === 'product') addImages(PUB.product.images, files, 4).then(renderPublish);
    else if (id === 'bookcover') prepImage(files[0]).then(function (r) { if (r) { if (PUB.book.cover) URL.revokeObjectURL(PUB.book.cover.preview); PUB.book.cover = r; } else toast('الصورة غير صالحة'); renderPublish(); });
    else if (id === 'zip') {
      var f = files[0];
      if (!/\.(zip|apk)$/i.test(f.name)) { toast('الملف يجب أن يكون .zip'); t.value = ''; return; }
      if (f.size > 60 * 1048576) { toast('الملف أكبر من 60MB'); t.value = ''; return; }
      PUB.app.zip = f; renderPublish();
    } else if (id === 'bookpdf') {
      var p = files[0];
      if (!/\.pdf$/i.test(p.name)) { toast('الملف يجب أن يكون PDF'); t.value = ''; return; }
      if (p.size > 40 * 1048576) { toast('الملف أكبر من 40MB'); t.value = ''; return; }
      PUB.book.pdf = p; renderPublish();
    }
  });
  window.pubDropImg = function (id, i) {
    if (id === 'app') dropImage(PUB.app.images, i); else if (id === 'product') dropImage(PUB.product.images, i);
    else if (id === 'bookcover') { if (PUB.book.cover) URL.revokeObjectURL(PUB.book.cover.preview); PUB.book.cover = null; }
    renderPublish();
  };

  /* ---------------- تطبيق: مراحل ---------------- */
  window.pubNext = function () {
    var A = PUB.app;
    if (PUB.step === 1) { if (A.title.trim().length < 2) return showErr('دخل اسم التطبيق (حرفين على الأقل).'); }
    if (PUB.step === 2) { if (!A.images.length) return showErr('زيد صورة وحدة على الأقل.'); }
    PUB.step = Math.min(3, PUB.step + 1); renderPublish(); window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  window.pubBack = function () { PUB.step = Math.max(1, PUB.step - 1); renderPublish(); };

  function needLogin() {
    if (logged()) return false;
    toast('سجّل الدخول أولاً'); renderPublish(); return true;
  }
  function afterAuthError(code) {
    if (code === 'unauthorized') { M1Views.logout(); if (window.applyAuthState) applyAuthState(false); renderPublish(); }
  }

  window.pubPublishApp = function () {
    var A = PUB.app;
    if (needLogin() || A.busy) return;
    if (A.title.trim().length < 2) { PUB.step = 1; renderPublish(); return showErr('دخل اسم التطبيق.'); }
    if (!A.images.length) { PUB.step = 2; renderPublish(); return showErr('زيد صورة وحدة على الأقل.'); }
    if (!A.zip) return showErr('اختر ملف ZIP أولاً.');
    A.busy = true; renderPublish();
    uploadMany(A.images, 'رفع الصور').then(function (ri) {
      if (!ri.ok) return fail(ri.error);
      return uploadMany([A.zip], 'رفع ملف ZIP').then(function (rz) {
        if (!rz.ok) return fail(rz.error);
        setProg('الفحص الآلي للتطبيق ونشره…', null);
        return M1Views.publishAppAuto({ title: A.title.trim(), category: A.category, desc: A.desc.trim(), images: ri.urls, zipUrl: rz.urls[0] }).then(function (r) {
          A.busy = false;
          if (!r.ok) { afterAuthError(r.error); A.result = { ok: false, error: r.error, report: r.report }; }
          else { A.result = { ok: true, id: r.id, live: r.live, report: r.report }; if (window.loadServerApps) loadServerApps(); }
          renderPublish();
        });
      });
    });
    function fail(code) { A.busy = false; afterAuthError(code); A.result = { ok: false, error: code, msg: errText(code) }; renderPublish(); }
  };
  window.pubPlay = function (id) {
    var go = function () { if (window.findApp && findApp(id)) openApp(id); else toast('التطبيق غادي يبان فـ«تطبيقاتي» بعد لحظات'); };
    if (window.loadServerApps) loadServerApps().then(go, go); else go();
  };

  /* ---------------- كتاب ---------------- */
  window.pubPublishBook = function () {
    var B = PUB.book;
    if (needLogin() || B.busy) return;
    if (B.title.trim().length < 2) return showErr('دخل عنوان الكتاب.');
    if (!B.cover) return showErr('زيد صورة الغلاف.');
    if (!B.pdf) return showErr('اختر ملف PDF.');
    B.busy = true; renderPublish();
    uploadMany([B.cover], 'رفع الغلاف').then(function (rc) {
      if (!rc.ok) return fail(rc.error);
      return uploadMany([B.pdf], 'رفع الكتاب').then(function (rp) {
        if (!rp.ok) return fail(rp.error);
        setProg('نشر الكتاب…', null);
        return M1Views.publishListing({ kind: 'book', title: B.title.trim(), author: B.author.trim(), desc: B.desc.trim(), images: rc.urls, fileUrl: rp.urls[0] }).then(function (r) {
          B.busy = false;
          if (!r.ok) { afterAuthError(r.error); renderPublish(); return showErr(errText(r.error)); }
          if (B.cover) URL.revokeObjectURL(B.cover.preview);
          PUB.book = { title: '', author: '', desc: '', cover: null, pdf: null, busy: false };
          toast('تم نشر الكتاب 📚');
          loadListings().then(function () { openAccount('books'); });
        });
      });
    });
    function fail(code) { B.busy = false; afterAuthError(code); renderPublish(); showErr(errText(code)); }
  };

  /* ---------------- منتج (دفع عند الاستلام) ---------------- */
  window.pubPublishProduct = function () {
    var P = PUB.product;
    if (needLogin() || P.busy) return;
    var price = Number(P.price);
    if (P.title.trim().length < 2) return showErr('دخل اسم المنتج.');
    if (P.city.trim().length < 2) return showErr('دخل اسم المدينة.');
    if (!(price > 0)) return showErr('دخل ثمن صحيح.');
    if (!/^(\+|00)?[0-9\s().\-]{8,20}$/.test(P.whatsapp.trim())) return showErr('دخل رقم واتساب صحيح (مثال: 0612345678).');
    if (!P.images.length) return showErr('زيد صورة وحدة على الأقل.');
    P.busy = true; renderPublish();
    uploadMany(P.images, 'رفع الصور').then(function (ri) {
      if (!ri.ok) return fail(ri.error);
      setProg('نشر المنتج…', null);
      return M1Views.publishListing({ kind: 'product', title: P.title.trim(), city: P.city.trim(), price: price, whatsapp: P.whatsapp.trim(), desc: P.desc.trim(), images: ri.urls }).then(function (r) {
        P.busy = false;
        if (!r.ok) { afterAuthError(r.error); renderPublish(); return showErr(errText(r.error)); }
        P.images.forEach(function (i) { URL.revokeObjectURL(i.preview); });
        PUB.product = { title: '', city: P.city, price: '', whatsapp: P.whatsapp, desc: '', images: [], busy: false };   // نحتفظ بالمدينة والواتساب للمنتج الموالي
        toast('تم نشر المنتج 🛍️');
        loadListings().then(function () { openAccount('products'); });
      });
    });
    function fail(code) { P.busy = false; afterAuthError(code); renderPublish(); showErr(errText(code)); }
  };

  /* ---------------- تحميل المنشورات (كتب + منتجات) ---------------- */
  function loadListings() {
    if (!window.M1Views || !M1Views.configured) return Promise.resolve();
    return Promise.all([M1Views.listings('book'), M1Views.listings('product')]).then(function (r) {
      if (r[0]) { LISTINGS.book = r[0]; try { localStorage.setItem('m1li_books', JSON.stringify(r[0].map(function (b) { b.mine = false; return b; }))); } catch (e) {} }
      if (r[1]) { LISTINGS.product = r[1]; try { localStorage.setItem('m1li_uprods', JSON.stringify(r[1].map(function (b) { b.mine = false; return b; }))); } catch (e) {} }
      paintAllListings();
    }, function () {});
  }
  window.loadListings = loadListings;
  function paintAllListings() {
    if (window.setUserProducts) setUserProducts(LISTINGS.product);
    renderHomeBooks();
    if (state && state.tab === 'books') renderBooks();
    if (state && state.tab === 'account') { paintBooks(); if (window.paintOrders) paintOrders(); }
  }

  /* ---------------- الكتب: الرئيسية + صفحة الكتب ---------------- */
  function bookCover(b) { return b.images && b.images[0] ? '<img src="' + esc(b.images[0]) + '" alt="" loading="lazy" referrerpolicy="no-referrer">' : '<i class="fa-solid fa-book"></i>'; }
  function renderHomeBooks() {
    var box = $('home-books'); if (!box) return;
    var list = LISTINGS.book.slice(0, 12);
    if (!list.length) { box.innerHTML = '<div class="acc-empty" style="padding:18px 8px"><i class="fa-solid fa-book" style="font-size:26px"></i>ما كاين حتى كتاب بعد. <button type="button" class="hb-pub" onclick="pubOpen(\'book\')">نشر أول كتاب</button></div>'; return; }
    box.innerHTML = list.map(function (b) {
      return '<a class="bk-card" href="' + esc(b.fileUrl) + '" target="_blank" rel="noopener"><div class="bk-cover">' + bookCover(b) + '</div>' +
        '<b>' + esc(b.title) + '</b><small>' + esc(b.author || b.seller || '') + '</small></a>';
    }).join('');
  }
  function renderBooks() {
    var grid = $('books-grid'); if (!grid) return;
    var q = ($('book-search') && $('book-search').value || '').trim().toLowerCase();
    var list = LISTINGS.book.filter(function (b) { return !q || (b.title + ' ' + b.author + ' ' + b.desc + ' ' + b.seller).toLowerCase().indexOf(q) !== -1; });
    $('books-empty').classList.toggle('hidden', list.length > 0);
    grid.innerHTML = list.map(function (b) {
      return '<article class="bk-full"><div class="bk-cover">' + bookCover(b) + '</div><div class="bk-info"><b>' + esc(b.title) + '</b>' +
        '<small>' + esc(b.author ? b.author + ' · ' : '') + 'نشره: ' + esc(b.seller) + '</small>' +
        (b.desc ? '<p>' + esc(b.desc) + '</p>' : '') +
        '<div class="bk-btns"><a class="acc-btn-main" href="' + esc(b.fileUrl) + '" target="_blank" rel="noopener"><i class="fa-solid fa-book-open-reader ml-1"></i> قراءة / تحميل</a>' +
        (b.mine ? '<button type="button" class="acc-btn-sm" style="color:#fb7185" onclick="pubDelete(\'' + jsq(b.id) + '\')">حذف</button>' : '') + '</div></div></article>';
    }).join('');
  }
  window.renderBooks = function () { renderBooks(); loadListings(); };
  window.renderHomeBooks = renderHomeBooks;

  /* ---------------- الحساب: كتبي / منتجاتي ---------------- */
  function mine(kind) { return LISTINGS[kind].filter(function (x) { return x.mine; }); }
  window.paintBooks = function () {
    var box = $('acc-panel-books'); if (!box) return;
    var top = '<div style="display:flex;justify-content:flex-end;margin-bottom:12px"><button type="button" class="acc-btn-main" onclick="pubOpen(\'book\')"><i class="fa-solid fa-plus ml-1"></i> نشر كتاب</button></div>';
    if (!logged()) { box.innerHTML = accLoginPrompt('سجّل الدخول باش تشوف كتبك.'); return; }
    var l = mine('book');
    box.innerHTML = top + (l.length ? l.map(function (b) {
      return '<div class="acc-item"><div class="acc-ico" style="overflow:hidden">' + bookCover(b) + '</div><div class="flex-1 min-w-0"><div class="font-bold text-sm text-white truncate">' + esc(b.title) + '</div>' +
        '<div class="text-[11px] text-slate-400">' + esc(b.author || 'PDF') + '</div></div>' +
        '<a class="acc-btn-sm" href="' + esc(b.fileUrl) + '" target="_blank" rel="noopener">فتح</a>' +
        '<button type="button" class="acc-btn-sm" style="color:#fb7185" onclick="pubDelete(\'' + jsq(b.id) + '\')">حذف</button></div>';
    }).join('') : '<div class="acc-empty"><i class="fa-solid fa-book-open"></i>ما نشرتي حتى كتاب بعد.</div>');
  };
  var _paintOrders = window.paintOrders;
  window.paintOrders = function () {
    if (_paintOrders) _paintOrders();
    var box = $('acc-panel-products'); if (!box) return;
    var l = logged() ? mine('product') : [];
    var html = '<div class="pb-mine"><div class="pb-mine-h"><b><i class="fa-solid fa-store ml-1"></i> منتجاتي المنشورة</b><button type="button" class="acc-btn-main" onclick="pubOpen(\'product\')"><i class="fa-solid fa-plus ml-1"></i> نشر منتج</button></div>' +
      (l.length ? l.map(function (p) {
        return '<div class="acc-item"><div class="acc-ico" style="overflow:hidden">' + (p.images && p.images[0] ? '<img src="' + esc(p.images[0]) + '" alt="" referrerpolicy="no-referrer">' : '🛍️') + '</div>' +
          '<div class="flex-1 min-w-0"><div class="font-bold text-sm text-white truncate">' + esc(p.title) + '</div><div class="text-[11px] text-slate-400">' + esc(p.price) + ' د.م · ' + esc(p.city) + '</div></div>' +
          '<button type="button" class="acc-btn-sm" style="color:#fb7185" onclick="pubDelete(\'' + jsq(p.id) + '\')">حذف</button></div>';
      }).join('') : '<div class="acc-empty" style="padding:14px"><i class="fa-solid fa-box-open"></i>' + (logged() ? 'ما نشرتي حتى منتج بعد.' : 'سجّل الدخول باش تنشر منتجاتك.') + '</div>') + '</div>';
    box.insertAdjacentHTML('afterbegin', html);
  };
  window.pubDelete = function (id) {
    if (!confirm('واش متأكد باغي تحذف هاد المنشور؟')) return;
    M1Views.deleteListing(id).then(function (r) { if (!r.ok) { toast(errText(r.error)); return; } toast('تم الحذف'); loadListings(); });
  };

  /* الحساب: حدّث القوائم عند فتحه */
  var _renderAccount = window.renderAccount;
  window.renderAccount = function () { if (_renderAccount) _renderAccount(); paintBooks(); loadListings(); };

  window.addEventListener('load', function () { renderHomeBooks(); setUserProducts(LISTINGS.product); loadListings(); });
})();
