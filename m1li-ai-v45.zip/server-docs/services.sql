-- m1li v34: جداول الخدمات (Escrow) + المهام. طبّقو مرة وحدة فـ Supabase SQL Editor.
-- الأعمدة مطابقة لاستعلامات server.js (amount_cents, release_at, ...).

create table if not exists service_orders (
  id            bigserial primary key,
  listing_id    text    not null,
  buyer_id      bigint  not null,
  seller_id     bigint  not null,
  title         text    not null,
  amount_cents  bigint  not null check (amount_cents > 0),
  fee_cents     bigint  not null check (fee_cents >= 0),
  ref_user_id   bigint,
  ref_cents     bigint  not null default 0,
  brief         text    not null default '',
  status        text    not null default 'awaiting_payment'
                check (status in ('awaiting_payment','funded','delivered','completed','disputed','refunded','cancelled')),
  note          text,
  pay_ref       text,
  created_at    bigint  not null,
  funded_at     bigint,
  delivered_at  bigint,
  release_at    bigint,
  completed_at  bigint
);
-- ⚠️ إلى كان عندك service_orders قديم بمخطط آخر، تأكد من الأعمدة قبل (انظر escrow-hardening.sql).

-- المهام: الأدمن كيزيدها، المستخدم كيدير المهمة ويبعت الإثبات، الأدمن كيقبل → نقاط معلّقة
create table if not exists tasks (
  id          bigserial primary key,
  title       text    not null,
  descr       text    not null default '',
  url         text    not null default '',
  kind        text    not null default 'other' check (kind in ('app','survey','ad','other')),
  points      integer not null check (points between 1 and 5000),
  max_total   integer not null default 0,      -- 0 = بلا حد على عدد المنجزين
  active      boolean not null default true,
  created_at  bigint  not null
);
create table if not exists task_submissions (
  id           bigserial primary key,
  task_id      bigint  not null references tasks(id) on delete cascade,
  user_id      bigint  not null,
  proof        text    not null,
  status       text    not null default 'pending' check (status in ('pending','approved','rejected')),
  points       integer not null default 0,
  note         text,
  created_at   bigint  not null,
  reviewed_at  bigint,
  unique (task_id, user_id)                    -- مهمة وحدة لكل مستخدم
);
create index if not exists task_sub_status_idx on task_submissions (status, id);
create index if not exists task_sub_user_idx   on task_submissions (user_id, id desc);

alter table service_orders    enable row level security;
alter table tasks             enable row level security;
alter table task_submissions  enable row level security;
