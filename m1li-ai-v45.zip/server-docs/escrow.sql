-- m1li: نظام الوساطة (Escrow) + العمولات — Supabase / Postgres
create table if not exists service_orders (
  id bigserial primary key,
  service_id text not null,
  buyer_id bigint not null,
  seller_id bigint not null,
  amount_mad numeric(10,2) not null check (amount_mad > 0),
  fee_mad numeric(10,2) not null default 0,           -- عمولة m1li
  status text not null default 'awaiting_payment'
    check (status in ('awaiting_payment','funded','delivered','completed','disputed','refunded','cancelled')),
  funded_at timestamptz, delivered_at timestamptz, completed_at timestamptz,
  auto_release_at timestamptz,                         -- مثلاً delivered_at + 72h إلا الزبون ما جاوبش
  ref_code text,                                       -- كود الرابح (إلا جا من رابط إحالة)
  created_at timestamptz default now()
);
create table if not exists wallet_ledger (               -- كل حركة فلوس سطر جديد، عمرها ما كتتبدل
  id bigserial primary key,
  user_id bigint not null,
  order_id bigint references service_orders(id),
  kind text not null check (kind in ('escrow_hold','release','refund','commission','fee','payout')),
  amount_mad numeric(10,2) not null,                   -- موجب = دخول، سالب = خروج
  created_at timestamptz default now()
);
create table if not exists referral_clicks (
  id bigserial primary key, ref_code text not null, target_id text not null, created_at timestamptz default now()
);
create table if not exists referral_commissions (
  id bigserial primary key, ref_code text not null, order_id bigint references service_orders(id),
  amount_mad numeric(10,2) not null,
  status text not null default 'pending' check (status in ('pending','approved','reversed')),  -- كتولي approved غير ملي الطلب يتكمل
  created_at timestamptz default now(), unique (order_id)
);
