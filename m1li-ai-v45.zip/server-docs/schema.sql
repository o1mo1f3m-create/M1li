-- m1li — schema.sql كامل (Postgres / Supabase). مستخرج من استعلامات server.js (الجرد v34).
-- طبّقو مرة وحدة: Supabase SQL Editor أو  psql "$DATABASE_URL" -f schema.sql
-- كله `if not exists` → آمن يتعاود. كل التواريخ = bigint بالميلي ثانية (Date.now()) كيف كيتوقع السيرفر.
-- السيرفر كيتصل مباشرة بـ DATABASE_URL (دور postgres) فكيتجاوز RLS؛ RLS مفعّل على كل الجداول باش ما يبانوش عبر API العمومي (anon).
-- ⚠️ ما تطبّقش escrow.sql: مخطط قديم (amount_mad / wallet_ledger) ما كيستعملو السيرفر.

-- ===== 1) المستخدمون والجلسات =====
create table if not exists users (
  id         bigserial primary key,
  phone      text   not null unique,            -- رقم حقيقي، أو 'n:<name>' (تسجيل بالاسم) أو 'g:<sub>' (Google)
  name       text   not null,
  salt       text   not null,
  pass_hash  text   not null,
  verified   integer not null default 0,
  email      text,
  google_sub text   unique,
  bio        text   not null default '',
  created_at bigint not null,
  last_seen  bigint not null default 0
);
create table if not exists sessions (
  token_hash text   primary key,
  user_id    bigint not null references users(id) on delete cascade,
  created_at bigint not null,
  expires_at bigint not null
);
create table if not exists otps (
  phone     text   primary key,
  code_hash text   not null,
  expires_at bigint not null,
  attempts  integer not null default 0,
  last_sent bigint not null default 0
);

-- ===== 2) المشاهدات / اللايكات / المتابعة / التنبيهات =====
create table if not exists views (
  id         bigserial primary key,
  ad_id      text   not null,
  device_id  text   not null,
  day        text   not null,                   -- YYYY-MM-DD
  ip_hash    text,
  ua         text,
  valid      integer not null default 0,
  reason     text,                              -- null | 'held' | سبب الرفض
  created_at bigint not null
);
create unique index if not exists uq_valid_view on views (ad_id, device_id, day) where valid = 1;  -- مشاهدة صالحة وحدة لكل جهاز/إعلان/يوم
create table if not exists likes (
  ad_id      text   not null,
  device_id  text   not null,
  created_at bigint not null,
  primary key (ad_id, device_id)
);
create table if not exists follows (
  dev        text   not null,
  device_id  text   not null,
  created_at bigint not null,
  primary key (dev, device_id)
);
create table if not exists alerts (
  id         bigserial primary key,
  ad_id      text   not null,
  kind       text   not null,                   -- spike | ip_concentration
  detail     text   not null default '',
  status     text   not null default 'open',
  created_at bigint not null
);

-- ===== 3) التطبيقات والإعلانات المبوّبة =====
create table if not exists apps (
  id         text   primary key,
  user_id    bigint not null references users(id) on delete cascade,
  title      text   not null,
  category   text   not null default '',
  "desc"     text   not null default '',
  icon       text   not null default '',
  type       text   not null default 'web',     -- web | android | android-src | other
  code       text   not null default '',
  url        text   not null default '',
  apk_url    text   not null default '',
  version    text   not null default '',
  status     text   not null default 'active',  -- active | removed
  images     text   not null default '[]',      -- JSON
  report     text   not null default '',        -- JSON
  created_at bigint not null,
  publish_at bigint not null default 0,
  updated_at bigint not null default 0
);
create table if not exists listings (
  id         text   primary key,                -- k_… (كتب) · s_… (خدمات) · l_… (منتجات)
  user_id    bigint not null references users(id) on delete cascade,
  kind       text   not null check (kind in ('product','book','service')),
  title      text   not null,
  "desc"     text   not null default '',
  price      numeric(12,2) not null default 0,
  city       text   not null default '',
  whatsapp   text   not null default '',
  images     text   not null default '[]',      -- JSON
  file_url   text   not null default '',
  extra      text   not null default '',
  status     text   not null default 'active',  -- active | removed
  created_at bigint not null
);

-- ===== 4) النقاط والأرباح =====
create table if not exists video_submissions (
  id             bigserial primary key,
  user_id        bigint not null references users(id) on delete cascade,
  platform       text   not null,
  video_url      text   not null,
  canon_url      text   not null unique,
  status         text   not null default 'pending',  -- pending | approved | rejected | revoked
  points_awarded integer not null default 0,
  note           text,
  created_at     bigint not null,
  reviewed_at    bigint
);
create table if not exists points_ledger (
  id           bigserial primary key,
  user_id      bigint  not null references users(id) on delete cascade,
  delta        integer not null,                -- موجب = كسب، سالب = سحب
  kind         text    not null,                -- adshare|checkin|refbonus|welcome|award|revoke|payout|refund|service|refcom|task
  ref_id       text,
  available_at bigint  not null,
  created_at   bigint  not null
);
create table if not exists payout_requests (
  id           bigserial primary key,
  user_id      bigint  not null references users(id) on delete cascade,
  points       integer not null,
  amount_mad   numeric(12,2) not null,
  method       text    not null,
  holder       text    not null default '',
  account      text    not null default '',
  status       text    not null default 'pending',
  note         text,
  created_at   bigint  not null,
  processed_at bigint
);
create table if not exists adsense_periods (
  month         text primary key,               -- YYYY-MM
  revenue_mad   numeric(12,2) not null,
  share_pct     numeric(5,2)  not null,
  total_views   bigint  not null default 0,
  points_total  bigint  not null default 0,
  publishers    integer not null default 0,
  created_at    bigint  not null
);

-- ===== 5) المتجر =====
create table if not exists shop_orders (
  id         text   primary key,
  status     text   not null default 'new',
  name       text   not null default '',
  phone      text   not null default '',
  city       text   not null default '',
  addr       text   not null default '',
  note       text   not null default '',
  items      text   not null default '[]',      -- JSON
  sub        numeric(12,2) not null default 0,
  fee        numeric(12,2) not null default 0,
  disc       numeric(12,2) not null default 0,
  total      numeric(12,2) not null default 0,
  coupon     text   not null default '',
  ip_hash    text,
  client_ts  bigint,
  created_at bigint not null,
  updated_at bigint
);

-- ===== 6) المكافآت (rewards.sql) =====
create table if not exists checkins (
  user_id    bigint  not null,
  day        text    not null,
  streak     integer not null,
  points     integer not null,
  created_at bigint  not null,
  primary key (user_id, day)
);
create table if not exists referrals (
  referee_id  bigint primary key,
  referrer_id bigint not null,
  created_at  bigint not null,
  paid_at     bigint
);

-- ===== 7) الخدمات (Escrow) + المهام (services.sql) =====
create table if not exists service_orders (
  id            bigserial primary key,
  listing_id    text    not null,
  buyer_id      bigint  not null,
  seller_id     bigint  not null,
  title         text    not null,
  amount_cents  bigint  not null check (amount_cents > 0),
  fee_cents     bigint  not null check (fee_cents >= 0),
  ref_user_id   bigint,
  ref_cents     bigint  not null default 0,
  brief         text    not null default '',
  status        text    not null default 'awaiting_payment'
                check (status in ('awaiting_payment','funded','delivered','completed','disputed','refunded','cancelled')),
  note          text,
  pay_ref       text,
  created_at    bigint  not null,
  funded_at     bigint,
  delivered_at  bigint,
  release_at    bigint,
  completed_at  bigint
);
create table if not exists tasks (
  id          bigserial primary key,
  title       text    not null,
  descr       text    not null default '',
  url         text    not null default '',
  kind        text    not null default 'other' check (kind in ('app','survey','ad','other')),
  points      integer not null check (points between 1 and 5000),
  max_total   integer not null default 0,
  active      boolean not null default true,
  created_at  bigint  not null
);
create table if not exists task_submissions (
  id           bigserial primary key,
  task_id      bigint  not null references tasks(id) on delete cascade,
  user_id      bigint  not null,
  proof        text    not null,
  status       text    not null default 'pending' check (status in ('pending','approved','rejected')),
  points       integer not null default 0,
  note         text,
  created_at   bigint  not null,
  reviewed_at  bigint,
  unique (task_id, user_id)
);

-- ===== 8) الفهارس (performance.sql + escrow-hardening.sql + services.sql) =====
create index if not exists views_ad_day_idx        on views (ad_id, day);
create index if not exists views_dev_day_idx       on views (device_id, day);
create index if not exists views_created_idx       on views (created_at);
create index if not exists likes_ad_dev_idx        on likes (ad_id, device_id);
create index if not exists follows_dev_idx         on follows (dev, device_id);
create index if not exists users_lname_idx         on users (lower(name));
create index if not exists sessions_user_idx       on sessions (user_id, created_at desc);
create index if not exists sessions_exp_idx        on sessions (expires_at);
create index if not exists apps_user_status_idx    on apps (user_id, status);
create index if not exists apps_status_created_idx on apps (status, created_at desc);
create index if not exists listings_kind_idx       on listings (kind, status, created_at desc);
create index if not exists listings_user_idx       on listings (user_id, status);
create index if not exists vsub_user_status_idx    on video_submissions (user_id, status);
create index if not exists vsub_status_idx         on video_submissions (status, id);
create index if not exists pl_user_avail_idx       on points_ledger (user_id, available_at);
create index if not exists pl_user_kind_idx        on points_ledger (user_id, kind);
create index if not exists payout_user_status_idx  on payout_requests (user_id, status);
create index if not exists payout_status_idx       on payout_requests (status, id);
create index if not exists shop_orders_created_idx on shop_orders (created_at desc);
create index if not exists shop_orders_ip_idx      on shop_orders (ip_hash, created_at);
create index if not exists otps_exp_idx            on otps (expires_at);
create index if not exists referrals_referrer_idx  on referrals (referrer_id);
create index if not exists task_sub_status_idx     on task_submissions (status, id);
create index if not exists task_sub_user_idx       on task_submissions (user_id, id desc);
create index if not exists service_orders_buyer_idx   on service_orders (buyer_id, id desc);
create index if not exists service_orders_seller_idx  on service_orders (seller_id, id desc);
create index if not exists service_orders_status_idx  on service_orders (status, id);
create index if not exists service_orders_release_idx on service_orders (release_at) where status = 'delivered';

-- ===== 9) RLS (بلا policies = ما كيوصل ليهم حتى anon/authenticated عبر API؛ السيرفر كيتجاوزها) =====
alter table users             enable row level security;
alter table sessions          enable row level security;
alter table otps              enable row level security;
alter table views             enable row level security;
alter table likes             enable row level security;
alter table follows           enable row level security;
alter table alerts            enable row level security;
alter table apps              enable row level security;
alter table listings          enable row level security;
alter table video_submissions enable row level security;
alter table points_ledger     enable row level security;
alter table payout_requests   enable row level security;
alter table adsense_periods   enable row level security;
alter table shop_orders       enable row level security;
alter table checkins          enable row level security;
alter table referrals         enable row level security;
alter table service_orders    enable row level security;
alter table tasks             enable row level security;
alter table task_submissions  enable row level security;

analyze;
