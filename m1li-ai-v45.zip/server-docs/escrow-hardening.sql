-- m1li: فهارس + RLS لجدول service_orders (المخطط الحقيقي لي كيستعملو server.js: amount_cents, release_at...).
-- ⚠️ هاد الملف كيعوّض النسخة القديمة لي كانت مبنية على escrow.sql (مخطط مختلف: amount_mad, auto_release_at, wallet_ledger).
-- طبّقو غير بعد ما تتأكد من الأعمدة بهاد الاستعلام (خاصو يرجع amount_cents و release_at):
--   select column_name from information_schema.columns where table_name = 'service_orders' order by ordinal_position;

create index if not exists service_orders_buyer_idx    on service_orders (buyer_id, id desc);
create index if not exists service_orders_seller_idx   on service_orders (seller_id, id desc);
create index if not exists service_orders_status_idx   on service_orders (status, id);
create index if not exists service_orders_release_idx  on service_orders (release_at) where status = 'delivered';

-- Supabase: بلا RLS الجدول كيبان عبر API العمومي بمفتاح anon. السيرفر كيتصل بـ DATABASE_URL مباشرة (دور postgres) وكيتجاوز RLS.
alter table service_orders enable row level security;
