-- m1li v39: مراجعات وتقييمات حقيقية للتطبيقات (مشتركة بين كل المستخدمين). طبّقو مرة وحدة فـ Supabase.
-- مراجعة وحدة لكل مستخدم فكل تطبيق (كتتعدّل ماشي كتتزاد). الإخفاء عبر status = 'hidden' من الإدارة.
create table if not exists app_reviews (
  id         bigserial primary key,
  app_id     text    not null,
  user_id    bigint  not null references users(id) on delete cascade,
  stars      integer not null check (stars between 1 and 5),
  body       text    not null default '' check (char_length(body) <= 300),
  status     text    not null default 'visible' check (status in ('visible','hidden')),
  created_at bigint  not null,
  updated_at bigint  not null,
  unique (app_id, user_id)
);
create index if not exists app_reviews_app_idx on app_reviews (app_id, status, created_at desc);

create or replace view app_rating_stats as
  select app_id, count(*)::int as count, round(avg(stars)::numeric, 2) as avg
    from app_reviews where status = 'visible' group by app_id;

alter table app_reviews enable row level security;
