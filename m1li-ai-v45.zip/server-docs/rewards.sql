-- m1li v34: المكافآت (حضور يومي + إحالة). طبّقو مرة وحدة فـ Supabase.
create table if not exists checkins (
  user_id    bigint  not null,
  day        text    not null,              -- YYYY-MM-DD بتوقيت المغرب
  streak     integer not null,
  points     integer not null,
  created_at bigint  not null,
  primary key (user_id, day)                -- حضور واحد فاليوم
);
create table if not exists referrals (
  referee_id  bigint primary key,           -- كل مستخدم كيتحسب لمُحيل واحد فقط
  referrer_id bigint not null,
  created_at  bigint not null,
  paid_at     bigint                        -- كيتعمر ملي كيتقبل ليه أول إنجاز → كتتدفع المكافأة مرة وحدة
);
create index if not exists referrals_referrer_idx on referrals (referrer_id);
alter table checkins  enable row level security;
alter table referrals enable row level security;
