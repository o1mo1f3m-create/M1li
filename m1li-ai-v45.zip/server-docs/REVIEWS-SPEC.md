# مراجعات التطبيقات (مطبّقة فـ server.js)

الواجهة (`app-reviews.js`) كتتصل بهاد الـ endpoints. إلى ما كانوش، الزر كيبين رسالة «المراجعات غير متاحة دابا» وما كيتكسر والو.

- `GET /api/reviews?app=<id>` → `{ ok, avg, count, reviews: [{ name, stars, body, created_at }] }` (آخر 30، `status='visible'` فقط، الاسم الأول فقط ماشي الهاتف).
- `POST /api/reviews` (Authorization: Bearer) body `{ app_id, stars (1-5), body (≤300) }` → upsert على `(app_id, user_id)`. أخطاء: `unauthorized`, `bad_input`, `rate_limited`.
- نصيحة: حد 10 مراجعات فالساعة لكل مستخدم، ومنع المطوّر من مراجعة تطبيقاتو. الإخفاء من لوحة الإدارة: `update app_reviews set status='hidden' where id=...`.

- التطبيق فـ `server.js`: دوال `reviewsGet` و`reviewSave`. ترتيب النشر: 1) طبّق `reviews.sql` فـ Supabase، 2) بدّل `server.js` ونشرو. قبل تطبيق الـ SQL كيرجع السيرفر `503 reviews_table_missing` والواجهة كتبين «المراجعات غير متاحة دابا».

- الإدارة: زر «💬 المراجعات» فـ `earn-admin.html` كيعرض آخر 100 مراجعة (حتى المخبية) مع إخفاء/إظهار. endpoints: `GET /api/admin/reviews` و`POST /api/admin/reviews/:id/hide|show`.
