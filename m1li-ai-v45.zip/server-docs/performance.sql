-- m1li v34: فهارس للاستعلامات الأكثر استعمالاً فـ server.js (كلها if not exists: آمنة تتعاود).
-- الأعمدة مأخوذة من استعلامات السيرفر نفسها. طبّقو فـ Supabase SQL Editor.
create index if not exists views_ad_day_idx        on views (ad_id, day);
create index if not exists views_dev_day_idx       on views (device_id, day);
create index if not exists views_created_idx       on views (created_at);
create index if not exists likes_ad_dev_idx        on likes (ad_id, device_id);
create index if not exists follows_dev_idx         on follows (dev, device_id);
create index if not exists users_lname_idx         on users (lower(name));
create index if not exists sessions_user_idx       on sessions (user_id, created_at desc);
create index if not exists sessions_exp_idx        on sessions (expires_at);
create index if not exists apps_user_status_idx    on apps (user_id, status);
create index if not exists apps_status_created_idx on apps (status, created_at desc);
create index if not exists listings_kind_idx       on listings (kind, status, created_at desc);
create index if not exists listings_user_idx       on listings (user_id, status);
create index if not exists vsub_user_status_idx    on video_submissions (user_id, status);
create index if not exists vsub_status_idx         on video_submissions (status, id);
create index if not exists pl_user_avail_idx       on points_ledger (user_id, available_at);
create index if not exists pl_user_kind_idx        on points_ledger (user_id, kind);
create index if not exists payout_user_status_idx  on payout_requests (user_id, status);
create index if not exists payout_status_idx       on payout_requests (status, id);
create index if not exists shop_orders_created_idx on shop_orders (created_at desc);
create index if not exists shop_orders_ip_idx      on shop_orders (ip_hash, created_at);
create index if not exists otps_exp_idx            on otps (expires_at);
-- بعد التطبيق: analyze;  (باش Postgres يحدّث الإحصائيات)
