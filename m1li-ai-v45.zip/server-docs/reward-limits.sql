-- m1li v38: حد يومي للنقاط (مكافحة الغش). طبّقو مرة وحدة فـ Supabase بعد rewards.sql.
-- كيخدم على مستوى قاعدة البيانات، يعني حتى إلى كان كود السيرفر ما عندو حتى فحص، الحد كيتطبّق.
-- افتراض: points_ledger.created_at بالميلي ثانية (Date.now()) واليوم كيتحسب بتوقيت UTC+1 (المغرب).
-- ملاحظة: ملي كيتجاوز المستخدم الحد، الإدراج كيفشل بخطأ 'daily_cap' → خاص السيرفر يرجّع ليه رسالة واضحة.

create table if not exists reward_caps (
  kind       text primary key,      -- نفس القيم ديال points_ledger.kind
  daily_cap  integer not null check (daily_cap > 0)
);

-- قيم مبدئية، بدّلها بحرية. اللي ما كاينش هنا (adshare, service, payout...) ما عندو حد.
insert into reward_caps (kind, daily_cap) values
  ('task',     200),    -- مهام/استطلاعات
  ('refbonus', 500),    -- مكافآت الإحالة (ضد تزوير الدعوات)
  ('refcom',   300)     -- عمولة الإحالة
on conflict (kind) do nothing;

create or replace function enforce_reward_cap() returns trigger as $$
declare
  cap  integer;
  used bigint;
  d    bigint;
begin
  if new.delta <= 0 then return new; end if;          -- السحب/الاسترجاع ما كيتحسبوش
  select daily_cap into cap from reward_caps where kind = new.kind;
  if cap is null then return new; end if;
  d := floor((new.created_at + 3600000) / 86400000.0);
  select coalesce(sum(delta), 0) into used
    from points_ledger
   where user_id = new.user_id and kind = new.kind and delta > 0
     and floor((created_at + 3600000) / 86400000.0) = d;
  if used + new.delta > cap then
    raise exception 'daily_cap' using errcode = 'P0001';
  end if;
  return new;
end;
$$ language plpgsql;

drop trigger if exists points_ledger_cap on points_ledger;
create trigger points_ledger_cap before insert on points_ledger
  for each row execute function enforce_reward_cap();

alter table reward_caps enable row level security;
