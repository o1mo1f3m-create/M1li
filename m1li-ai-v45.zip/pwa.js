/* m1li PWA: زر التثبيت (أندرويد) + تلميح iPhone + تفعيل الإشعارات */
(function () {
  var dismissed = false, deferred = null;
  var standalone = window.matchMedia('(display-mode: standalone)').matches || navigator.standalone;
  if (standalone) return;
  try { if (localStorage.getItem('m1li_pwa_hide') > Date.now()) return; } catch (_) {}

  function bar(text, btnText, onClick) {
    if (document.getElementById('m1li-pwa-bar')) return;
    var b = document.createElement('div'); b.id = 'm1li-pwa-bar';
    b.style.cssText = 'position:fixed;left:12px;right:12px;bottom:12px;z-index:99999;background:#1877f2;color:#fff;border-radius:14px;padding:12px 14px;display:flex;gap:10px;align-items:center;font:600 14px system-ui,sans-serif;direction:rtl;box-shadow:0 6px 24px rgba(0,0,0,.25)';
    var t = document.createElement('span'); t.style.flex = '1'; t.textContent = text; b.appendChild(t);
    if (btnText) {
      var ok = document.createElement('button'); ok.textContent = btnText;
      ok.style.cssText = 'background:#fff;color:#1877f2;border:0;border-radius:9px;padding:8px 14px;font-weight:800';
      ok.onclick = function () { onClick(); b.remove(); }; b.appendChild(ok);
    }
    var x = document.createElement('button'); x.textContent = '✕'; x.setAttribute('aria-label', 'إغلاق');
    x.style.cssText = 'background:none;border:0;color:#fff;font-size:18px';
    x.onclick = function () { b.remove(); try { localStorage.setItem('m1li_pwa_hide', Date.now() + 7 * 864e5); } catch (_) {} };
    b.appendChild(x); document.body.appendChild(b);
  }

  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault(); deferred = e;
    setTimeout(function () {
      bar('ثبّت m1li فهاتفك — كيخدم بحال تطبيق', 'تثبيت', function () { deferred.prompt(); deferred = null; });
    }, 8000);
  });
  window.addEventListener('appinstalled', function () { var b = document.getElementById('m1li-pwa-bar'); if (b) b.remove(); });

  // iPhone: ما كاينش beforeinstallprompt
  var ios = /iphone|ipad|ipod/i.test(navigator.userAgent) && !window.MSStream;
  if (ios) setTimeout(function () { bar('فـ Safari: دوّز على «مشاركة» ثم «إضافة إلى الشاشة الرئيسية»', null); }, 10000);

  // تفعيل الإشعارات: كتستدعى من زر فالتطبيق: M1LI_ENABLE_PUSH()
  window.M1LI_ENABLE_PUSH = function () {
    if (!('Notification' in window) || !('serviceWorker' in navigator)) return Promise.resolve('unsupported');
    return Notification.requestPermission().then(function (p) {
      if (p !== 'granted') return p;
      return navigator.serviceWorker.ready.then(function (r) {
        return r.showNotification('m1li', { body: 'تفعلات الإشعارات ✅', icon: 'icon-192.png', dir: 'rtl', lang: 'ar' });
      }).then(function () { return 'granted'; });
    });
  };
})();
