/* ============================================================
   مساعد m1li الذكي — فقاعة دردشة فالمتجر (كتجاوب بلغة الزبون: دارجة / فرنسية / إنجليزية)
   كيخدم غير إذا كان السيرفر فيه ANTHROPIC_API_KEY، وإلا ما كتبان حتى فقاعة.
   ============================================================ */
(function () {
  var API = String(window.M1LI_API || '').replace(/\/+$/, '');
  if (!API) return;
  var history = [], busy = false, built = false;

  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function catalog() {
    var list = (typeof products !== 'undefined' && products) ? products : [];
    var out = list.slice(0, 40).map(function (p) { return { id: p.id, kind: 'product', title: p.title, price: p.price, category: p.category }; });
    try {
      if (typeof allApps === 'function') {
        allApps().filter(function (a) { return a && a.live !== false; }).slice(0, 30).forEach(function (a) {
          out.push({ id: a.id, kind: 'app', title: a.title, category: a.category, desc: String(a.desc || '').slice(0, 50) });
        });
      }
    } catch (_) {}
    return out;
  }
  function lang() {
    var l = String(navigator.language || 'ar').slice(0, 2).toLowerCase();
    return (l === 'fr' || l === 'en') ? l : 'ar';
  }
  function addMsg(role, text) {
    var box = document.getElementById('aic-msgs');
    var b = el('div', 'aic-msg ' + (role === 'user' ? 'aic-user' : 'aic-bot'), text);
    box.appendChild(b); box.scrollTop = box.scrollHeight; return b;
  }
  function addCards(ids) {
    var box = document.getElementById('aic-msgs'), wrap = el('div', 'aic-cards');
    ids.forEach(function (id) {
      var p = (typeof findProduct === 'function') ? findProduct(id) : null;
      var a = (!p && typeof findApp === 'function') ? findApp(id) : null;
      if (!p && !a) return;
      var b = el('button', 'aic-card'); b.type = 'button';
      b.appendChild(el('span', 'aic-card-t', (a ? (a.icon || '📱') + ' ' : '') + (p || a).title));
      b.appendChild(el('span', 'aic-card-p', p ? ((typeof money === 'function') ? money(p.price) : String(p.price)) : 'تطبيق'));
      b.onclick = function () { toggle(false); if (p && typeof openProduct === 'function') openProduct(id); else if (a && typeof openApp === 'function') openApp(id); };
      wrap.appendChild(b);
    });
    if (wrap.childNodes.length) { box.appendChild(wrap); box.scrollTop = box.scrollHeight; }
  }
  function errMsg(code) {
    if (code === 'ai_rate_limited' || code === 'ai_daily_limit' || code === 'rate_limited') return 'كثرو الطلبات دابا. عاود جرّب من بعد شوية 🙏';
    return 'ما قدرتش نجاوب دابا. عاود حاول من بعد.';
  }
  function send(text) {
    text = String(text || '').trim().slice(0, 500);
    if (!text || busy) return;
    busy = true; addMsg('user', text); history.push({ role: 'user', content: text });
    var wait = addMsg('bot', '…'); wait.classList.add('aic-wait');
    document.getElementById('aic-send').disabled = true;
    fetch(API + '/api/ai/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages: history.slice(-8), catalog: catalog(), lang: lang() }) })
      .then(function (r) { return r.json().catch(function () { return {}; }); })
      .then(function (j) {
        if (j && j.ok && j.reply) { wait.textContent = j.reply; wait.classList.remove('aic-wait'); history.push({ role: 'assistant', content: j.reply }); addCards(j.ids || []); }
        else { wait.textContent = errMsg(j && j.error); wait.classList.remove('aic-wait'); history.pop(); }
      })
      .catch(function () { wait.textContent = errMsg(''); wait.classList.remove('aic-wait'); history.pop(); })
      .then(function () { busy = false; var s = document.getElementById('aic-send'); if (s) s.disabled = false; });
  }
  function toggle(open) {
    var p = document.getElementById('aic-panel'); if (!p) return;
    var show = open == null ? p.classList.contains('aic-hidden') : open;
    p.classList.toggle('aic-hidden', !show);
    if (show) { var i = document.getElementById('aic-input'); if (i) setTimeout(function () { i.focus(); }, 50); }
  }
  function build() {
    if (built) return; built = true;
    var css = el('style'); css.textContent =
      '#aic-fab{position:fixed;left:14px;bottom:calc(86px + env(safe-area-inset-bottom));z-index:45;width:54px;height:54px;border-radius:50%;border:0;cursor:pointer;font-size:24px;color:#fff;background:linear-gradient(135deg,#6366f1,#10b981);box-shadow:0 6px 20px rgba(0,0,0,.45)}' +
      '#aic-panel{position:fixed;left:12px;bottom:calc(150px + env(safe-area-inset-bottom));z-index:45;width:min(92vw,380px);height:min(70vh,520px);display:flex;flex-direction:column;background:#0f172a;border:1px solid #334155;border-radius:18px;box-shadow:0 12px 40px rgba(0,0,0,.6);overflow:hidden}' +
      '#aic-panel.aic-hidden{display:none}' +
      '.aic-head{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:#1e293b;color:#fff;font-weight:800;font-size:14px}' +
      '.aic-head button{background:none;border:0;color:#94a3b8;font-size:18px;cursor:pointer}' +
      '#aic-msgs{flex:1;overflow-y:auto;padding:12px;display:flex;flex-direction:column;gap:8px}' +
      '.aic-msg{max-width:86%;padding:8px 12px;border-radius:14px;font-size:13px;line-height:1.6;white-space:pre-wrap;word-break:break-word}' +
      '.aic-bot{align-self:flex-start;background:#1e293b;color:#e2e8f0}.aic-user{align-self:flex-end;background:#4f46e5;color:#fff}.aic-wait{opacity:.6}' +
      '.aic-chips{display:flex;flex-wrap:wrap;gap:6px}.aic-chips button{font-size:12px;padding:5px 10px;border-radius:999px;border:1px solid #334155;background:#0f172a;color:#cbd5e1;cursor:pointer}' +
      '.aic-cards{display:flex;gap:8px;overflow-x:auto;padding-bottom:4px}' +
      '.aic-card{flex:0 0 auto;max-width:150px;text-align:start;padding:8px 10px;border-radius:12px;border:1px solid #334155;background:#0b1220;color:#fff;cursor:pointer;display:flex;flex-direction:column;gap:2px}' +
      '.aic-card-t{font-size:12px;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.aic-card-p{font-size:12px;color:#34d399;font-weight:800}' +
      '.aic-form{display:flex;gap:6px;padding:8px;border-top:1px solid #334155;background:#0b1220}' +
      '#aic-input{flex:1;min-width:0;padding:9px 12px;border-radius:12px;border:1px solid #334155;background:#0f172a;color:#fff;font-size:13px}' +
      '#aic-send{padding:0 14px;border:0;border-radius:12px;background:#10b981;color:#fff;font-weight:800;cursor:pointer}#aic-send:disabled{opacity:.5}';
    document.head.appendChild(css);

    var fab = el('button', null, '✨'); fab.id = 'aic-fab'; fab.type = 'button'; fab.setAttribute('aria-label', 'مساعد m1li الذكي');
    fab.onclick = function () { toggle(); };
    var panel = el('div'); panel.id = 'aic-panel'; panel.className = 'aic-hidden';
    var head = el('div', 'aic-head'); head.appendChild(el('span', null, '✨ مساعد m1li'));
    var x = el('button', null, '✕'); x.type = 'button'; x.onclick = function () { toggle(false); }; head.appendChild(x);
    var msgs = el('div'); msgs.id = 'aic-msgs';
    var form = el('form', 'aic-form');
    var inp = el('input'); inp.id = 'aic-input'; inp.maxLength = 500; inp.placeholder = ({ ar: 'اكتب سؤالك…', fr: 'Votre question…', en: 'Ask me anything…' })[lang()]; inp.autocomplete = 'off';
    var btn = el('button', null, ({ ar: 'سيفط', fr: 'Envoyer', en: 'Send' })[lang()]); btn.id = 'aic-send'; btn.type = 'submit';
    form.appendChild(inp); form.appendChild(btn);
    form.onsubmit = function (e) { e.preventDefault(); var v = inp.value; inp.value = ''; send(v); };
    panel.appendChild(head); panel.appendChild(msgs); panel.appendChild(form);
    document.body.appendChild(fab); document.body.appendChild(panel);
    var L = lang();
    var WEL = {
      ar: 'سلام 👋 أنا مساعد m1li. قولي شنو كتقلّب عليه (منتج، تطبيق، لعبة…) وغادي نقترح عليك من اللي كاين. كنفهم الدارجة، Français, English.',
      fr: 'Salut 👋 Je suis l\'assistant m1li. Dites-moi ce que vous cherchez (produit, appli, jeu…) et je vous propose ce qui existe. Je comprends aussi l\'arabe et l\'anglais.',
      en: 'Hi 👋 I\'m the m1li assistant. Tell me what you\'re looking for (a product, app, game…) and I\'ll suggest what\'s available. I also understand Arabic and French.'
    };
    var CH = {
      ar: ['بغيت لعبة نلعبها', 'شنو كاين فالمتجر؟', 'بغيت كتاب مزيان', 'كيفاش نبيع تطبيقي؟'],
      fr: ['Une appli utile ?', 'Je cherche un cadeau', 'Quoi de neuf ?', 'Comment publier mon appli ?'],
      en: ['Show me games', 'What\'s in the store?', 'Do you ship abroad?', 'How do I publish my app?']
    };
    addMsg('bot', WEL[L]);
    var chips = el('div', 'aic-chips');
    CH[L].forEach(function (t) {
      var c = el('button', null, t); c.type = 'button'; c.onclick = function () { chips.remove(); send(t); }; chips.appendChild(c);
    });
    msgs.appendChild(chips);
  }
  // الفقاعة كتبان غير إذا الذكاء الاصطناعي مفعّل فالسيرفر
  fetch(API + '/api/ai/status', { cache: 'no-store' }).then(function (r) { return r.json(); })
    .then(function (j) { if (j && j.enabled) build(); }).catch(function () {});
})();
