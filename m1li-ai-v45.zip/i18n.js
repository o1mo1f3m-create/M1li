/* m1li i18n — ترجمة الواجهة (ar / fr / en / es) بقاموس نصوص + مراقب DOM.
   العربية هي الأصل. النص لي ما كاينش فالقاموس كيبقى بالعربية (بما فيها الشروط والأحكام ومحتوى المستخدمين).
   باش تزيد جملة: زيدها فـ D بالشكل "العربية": ["fr","en","es"]. */
(function () {
  var D = {
    "تطبيقات": ["Applications", "Apps", "Aplicaciones"], "التطبيقات": ["Applications", "Apps", "Aplicaciones"], "تطبيق": ["Application", "App", "Aplicación"],
    "أدوات": ["Outils", "Tools", "Herramientas"], "أدوات (Tools)": ["Outils", "Tools", "Herramientas"],
    "ألعاب": ["Jeux", "Games", "Juegos"], "ألعاب (Games)": ["Jeux", "Games", "Juegos"],
    "إنتاجية": ["Productivité", "Productivity", "Productividad"], "إنتاجية (Productivity)": ["Productivité", "Productivity", "Productividad"],
    "أسلوب حياة": ["Style de vie", "Lifestyle", "Estilo de vida"], "أسلوب حياة (Lifestyle)": ["Style de vie", "Lifestyle", "Estilo de vida"],
    "طلبات الخدمات": ["Commandes de services", "Service orders", "Pedidos de servicios"],
    "الكل": ["Tout", "All", "Todo"], "الرئيسية": ["Accueil", "Home", "Inicio"],
    "المنتجات": ["Produits", "Products", "Productos"], "منتجات": ["Produits", "Products", "Productos"], "منتج": ["Produit", "Product", "Producto"],
    "الكتب": ["Livres", "Books", "Libros"], "كتاب": ["Livre", "Book", "Libro"], "خدمات": ["Services", "Services", "Servicios"],
    "المفضلة": ["Favoris", "Favorites", "Favoritos"], "حسابي": ["Mon compte", "My account", "Mi cuenta"],
    "اربح": ["Gagner", "Earn", "Ganar"], "اربح مع m1li": ["Gagnez avec m1li", "Earn with m1li", "Gana con m1li"],
    "الإعدادات": ["Paramètres", "Settings", "Ajustes"], "المظهر": ["Apparence", "Appearance", "Apariencia"],
    "الوضع الداكن": ["Mode sombre", "Dark mode", "Modo oscuro"],
    "التبديل بين الوضع الداكن والفاتح": ["Basculer entre mode sombre et mode clair", "Switch between dark and light mode", "Cambiar entre modo oscuro y claro"],
    "تبديل المظهر": ["Changer d'apparence", "Toggle theme", "Cambiar tema"],
    "الخصوصية": ["Confidentialité", "Privacy", "Privacidad"], "الشروط والأحكام": ["Conditions générales", "Terms & Conditions", "Términos y condiciones"], "من نحن": ["À propos", "About us", "Quiénes somos"],
    "اللغة": ["Langue", "Language", "Idioma"], "اختر لغة الواجهة": ["Choisissez la langue de l'interface", "Choose the interface language", "Elige el idioma de la interfaz"],
    "أضف إلى السلة": ["Ajouter au panier", "Add to cart", "Añadir al carrito"], "سلة التسوق": ["Panier", "Shopping cart", "Carrito de compras"],
    "السلة فارغة. أضف بعض المنتجات 🛍️": ["Le panier est vide. Ajoutez des produits 🛍️", "Your cart is empty. Add some products 🛍️", "El carrito está vacío. Añade productos 🛍️"],
    "تفريغ السلة": ["Vider le panier", "Clear cart", "Vaciar carrito"], "المجموع": ["Total", "Total", "Total"], "الإجمالي": ["Total", "Total", "Total"],
    "اطلب عبر واتساب (الدفع عند الاستلام)": ["Commander via WhatsApp (paiement à la livraison)", "Order via WhatsApp (cash on delivery)", "Pedir por WhatsApp (pago contra entrega)"],
    "الدفع عند الاستلام": ["Paiement à la livraison", "Cash on delivery", "Pago contra entrega"],
    "الدفع عند الاستلام — لا تدفع شيئاً الآن": ["Paiement à la livraison — ne payez rien maintenant", "Cash on delivery — pay nothing now", "Pago contra entrega — no pagas nada ahora"],
    "تأكيد الطلب عبر الواتساب": ["Confirmer la commande via WhatsApp", "Confirm order via WhatsApp", "Confirmar el pedido por WhatsApp"],
    "معلومات التوصيل": ["Informations de livraison", "Delivery information", "Información de entrega"], "التوصيل": ["Livraison", "Delivery", "Entrega"],
    "توصيل لجميع المدن": ["Livraison dans toutes les villes", "Delivery to all cities", "Entrega a todas las ciudades"],
    "تتبع طلبي": ["Suivre ma commande", "Track my order", "Seguir mi pedido"], "تتبع طلبك": ["Suivre votre commande", "Track your order", "Sigue tu pedido"], "تتبع": ["Suivre", "Track", "Seguir"],
    "رقم الطلب": ["N° de commande", "Order number", "N.º de pedido"], "تم تسجيل طلبك": ["Votre commande est enregistrée", "Your order has been placed", "Tu pedido fue registrado"],
    "الأحدث": ["Plus récents", "Newest", "Más recientes"], "الأعلى تقييماً": ["Mieux notés", "Top rated", "Mejor valorados"], "الأكثر تشغيلاً": ["Plus utilisés", "Most played", "Más usados"],
    "فتح": ["Ouvrir", "Open", "Abrir"], "تشغيل": ["Lancer", "Run", "Ejecutar"], "إغلاق": ["Fermer", "Close", "Cerrar"], "إلغاء التعديل": ["Annuler la modification", "Cancel edit", "Cancelar edición"],
    "إزالة": ["Retirer", "Remove", "Quitar"], "نسخ": ["Copier", "Copy", "Copiar"], "مسح": ["Effacer", "Clear", "Borrar"], "تصدير": ["Exporter", "Export", "Exportar"],
    "تصدير بياناتي": ["Exporter mes données", "Export my data", "Exportar mis datos"], "مسح جميع البيانات": ["Effacer toutes les données", "Delete all data", "Borrar todos los datos"],
    "معاينة": ["Aperçu", "Preview", "Vista previa"], "مشاركة": ["Partager", "Share", "Compartir"], "ملء الشاشة": ["Plein écran", "Fullscreen", "Pantalla completa"],
    "السابقة": ["Précédent", "Previous", "Anterior"], "التالية": ["Suivant", "Next", "Siguiente"], "التنقل": ["Navigation", "Navigation", "Navegación"],
    "نشر": ["Publier", "Publish", "Publicar"], "انشر": ["Publier", "Publish", "Publicar"], "نشر التطبيق": ["Publier l'application", "Publish app", "Publicar la aplicación"],
    "نشر تطبيق": ["Publier une application", "Publish an app", "Publicar una aplicación"], "نشر كتاب": ["Publier un livre", "Publish a book", "Publicar un libro"],
    "نشر تطبيق جديد على m1li": ["Publier une nouvelle appli sur m1li", "Publish a new app on m1li", "Publicar una nueva app en m1li"],
    "تسجيل الدخول / إنشاء حساب": ["Connexion / Créer un compte", "Sign in / Create account", "Iniciar sesión / Crear cuenta"],
    "تسجيل الدخول للنشر": ["Connectez-vous pour publier", "Sign in to publish", "Inicia sesión para publicar"],
    "تسجيل الخروج": ["Déconnexion", "Sign out", "Cerrar sesión"], "دخول": ["Connexion", "Sign in", "Entrar"],
    "أو برقم الهاتف": ["Ou avec le numéro de téléphone", "Or with phone number", "O con número de teléfono"],
    "رقم الهاتف": ["Numéro de téléphone", "Phone number", "Número de teléfono"],
    "نسيت كلمة السر؟": ["Mot de passe oublié ?", "Forgot password?", "¿Olvidaste tu contraseña?"],
    "استرجاع كلمة السر": ["Récupérer le mot de passe", "Reset password", "Restablecer contraseña"],
    "رجوع لتسجيل الدخول": ["Retour à la connexion", "Back to sign in", "Volver al inicio de sesión"],
    "ليس لديك حساب؟ أنشئ حساباً": ["Pas de compte ? Créez-en un", "Don't have an account? Create one", "¿No tienes cuenta? Crea una"],
    "إرسال الرمز": ["Envoyer le code", "Send code", "Enviar código"], "إعادة الإرسال": ["Renvoyer", "Resend", "Reenviar"],
    "تأكيد الرقم": ["Confirmer le numéro", "Verify number", "Confirmar número"],
    "أكّد رقم هاتفك للنشر": ["Confirmez votre numéro pour publier", "Verify your phone to publish", "Confirma tu teléfono para publicar"],
    "تخطّي": ["Passer", "Skip", "Omitir"], "مرحباً بك": ["Bienvenue", "Welcome", "Bienvenido"], "مرحباً بك في m1li": ["Bienvenue sur m1li", "Welcome to m1li", "Bienvenido a m1li"],
    "رصيدي": ["Mon solde", "My balance", "Mi saldo"], "رصيد متاح": ["Solde disponible", "Available balance", "Saldo disponible"],
    "سحب الأرباح": ["Retirer les gains", "Withdraw earnings", "Retirar ganancias"], "طلب السحب": ["Demande de retrait", "Withdrawal request", "Solicitar retiro"],
    "معلوماتي": ["Mes infos", "My info", "Mi información"], "تطبيقاتي": ["Mes applications", "My apps", "Mis aplicaciones"],
    "تطبيقاتي المنشورة": ["Mes applis publiées", "My published apps", "Mis apps publicadas"], "تطبيقاتي المفضلة": ["Mes applis favorites", "My favorite apps", "Mis apps favoritas"],
    "منتجاتي": ["Mes produits", "My products", "Mis productos"], "كتبي": ["Mes livres", "My books", "Mis libros"],
    "لا توجد تطبيقات مفضلة": ["Aucune appli favorite", "No favorite apps", "Sin apps favoritas"],
    "لا توجد منتجات مطابقة.": ["Aucun produit correspondant.", "No matching products.", "No hay productos coincidentes."],
    "لم يتم العثور على أي تطبيق": ["Aucune application trouvée", "No apps found", "No se encontró ninguna app"],
    "جرب البحث بكلمة أخرى أو اختر تصنيفاً مختلفاً.": ["Essayez un autre mot-clé ou une autre catégorie.", "Try another keyword or a different category.", "Prueba otra palabra o elige otra categoría."],
    "عرض الكل": ["Voir tout", "View all", "Ver todo"], "عرض جميع التطبيقات": ["Voir toutes les applications", "View all apps", "Ver todas las apps"],
    "تصفح المتجر": ["Parcourir la boutique", "Browse the store", "Explorar la tienda"], "شري من أمازون": ["Acheter sur Amazon", "Buy on Amazon", "Comprar en Amazon"],
    "مزيد من العروض 🔥": ["Plus d'offres 🔥", "More deals 🔥", "Más ofertas 🔥"], "قيّم التطبيق": ["Notez l'application", "Rate the app", "Valora la app"],
    "تقييم": ["Note", "Rating", "Valoración"], "الإصدار": ["Version", "Version", "Versión"],
    "مركز المطورين": ["Espace développeurs", "Developer hub", "Centro de desarrolladores"],
    "أرسل فيديو للمراجعة": ["Envoyer une vidéo pour examen", "Send a video for review", "Enviar vídeo para revisión"],
    "إرسال للمراجعة": ["Envoyer pour examen", "Submit for review", "Enviar para revisión"], "معلّق": ["En attente", "Pending", "Pendiente"],
    "جاري الفحص...": ["Analyse en cours...", "Scanning...", "Analizando..."], "فحص آلي للكود": ["Analyse automatique du code", "Automated code scan", "Análisis automático de código"],
    "اسم التطبيق / اللعبة": ["Nom de l'appli / du jeu", "App / game name", "Nombre de la app / juego"],
    "اسم المطور / الناشر": ["Nom du développeur / éditeur", "Developer / publisher name", "Nombre del desarrollador / editor"],
    "وصف مختصر": ["Courte description", "Short description", "Descripción corta"], "الفئة": ["Catégorie", "Category", "Categoría"],
    "الاسم الكامل": ["Nom complet", "Full name", "Nombre completo"],
    "كلمة السر (8 أحرف على الأقل)": ["Mot de passe (8 caractères min.)", "Password (at least 8 characters)", "Contraseña (mínimo 8 caracteres)"],
    "رمز التأكيد (6 أرقام)": ["Code de confirmation (6 chiffres)", "Confirmation code (6 digits)", "Código de confirmación (6 dígitos)"],
    "الرجوع للرئيسية": ["Retour à l'accueil", "Back to home", "Volver al inicio"], "الكود ديالك": ["Votre code", "Your code", "Tu código"],
    "خصم الكود": ["Remise code", "Code discount", "Descuento del código"], "خصم النقاط": ["Remise points", "Points discount", "Descuento por puntos"],
    "المبلغ عند الاستلام": ["Montant à la livraison", "Amount due on delivery", "Importe a pagar en la entrega"],
    "لم يفتح الواتساب؟ افتحه مجدداً": ["WhatsApp ne s'est pas ouvert ? Rouvrez-le", "WhatsApp didn't open? Open it again", "¿No se abrió WhatsApp? Ábrelo de nuevo"],
    "خاصك حساب (رقم هاتف) باش تبدا تربح النقاط.": ["Il vous faut un compte (numéro de téléphone) pour gagner des points.", "You need an account (phone number) to start earning points.", "Necesitas una cuenta (teléfono) para empezar a ganar puntos."],
    "سجّل الدخول لتنشر وتربح": ["Connectez-vous pour publier et gagner", "Sign in to publish and earn", "Inicia sesión para publicar y ganar"],
    "صوّر فيديو، اجمع النقاط وسحبها دراهم": ["Filmez une vidéo, cumulez des points et retirez en dirhams", "Shoot a video, collect points and cash out in dirhams", "Graba un vídeo, acumula puntos y retíralos en dírhams"],
    "لوحة الطلبات (للتاجر)": ["Tableau des commandes (marchand)", "Orders dashboard (merchant)", "Panel de pedidos (comerciante)"],
    "ملاحظات (اختياري)": ["Remarques (facultatif)", "Notes (optional)", "Notas (opcional)"],
    "فتح / تثبيت كتطبيق": ["Ouvrir / installer comme appli", "Open / install as app", "Abrir / instalar como app"],
    "تشغيل التطبيق": ["Lancer l'application", "Run app", "Ejecutar la aplicación"],
    "كود الخصم": ["Code promo", "Discount code", "Código de descuento"], "عدد النقاط": ["Nombre de points", "Number of points", "Número de puntos"],
    "ابحث عن لعبة، أداة، أو تطبيق...": ["Rechercher un jeu, un outil ou une appli...", "Search for a game, tool, or app...", "Busca un juego, herramienta o app..."],
    "ابحث عن منتج...": ["Rechercher un produit...", "Search for a product...", "Buscar un producto..."], "ابحث عن كتاب...": ["Rechercher un livre...", "Search for a book...", "Buscar un libro..."],
    "العنوان الكامل * (الحي، الشارع، رقم المنزل)": ["Adresse complète * (quartier, rue, n°)", "Full address * (neighborhood, street, house no.)", "Dirección completa * (barrio, calle, n.º)"]
  };
  var IDX = { fr: 0, en: 1, es: 2 };
  var SUGGEST = {
    fr: ['Voir le site en français ?', 'Français'], en: ['View this site in English?', 'English'], es: ['¿Ver el sitio en español?', 'Español']
  };
  var KEY = 'm1li_lang', lang = 'ar', recs = new WeakMap(), obs = null;

  function tr(str) {
    if (lang === 'ar') return null;
    var m = /^(\s*)([\s\S]*?)(\s*)$/.exec(str); if (!m || !m[2]) return null;
    var core = m[2].replace(/\s+/g, ' ');
    var hit = D[core], pre = '', suf = '';
    if (!hit) {
      var p = /^([^\p{L}\p{N}]*)(.*?)([^\p{L}\p{N}]*)$/u.exec(core);
      if (p && p[2] && (D[p[2]])) { hit = D[p[2]]; pre = p[1]; suf = p[3]; }
    }
    if (!hit) return null;
    return m[1] + pre + hit[IDX[lang]] + suf + m[3];
  }
  function text(node) {
    var rec = recs.get(node);
    if (rec && node.nodeValue === rec.out) {
      // النص حنا لي ترجمناه: نعاودو نترجمو من الأصل العربي للغة الحالية (أو نرجعو للأصل)
      var again = lang === 'ar' ? rec.orig : tr(rec.orig);
      if (again == null) again = rec.orig;
      if (again !== node.nodeValue) node.nodeValue = again;
      if (again === rec.orig) recs.delete(node); else rec.out = again;
      return;
    }
    var orig = node.nodeValue;
    var out = tr(orig);
    if (out != null && out !== orig) { recs.set(node, { orig: orig, out: out }); node.nodeValue = out; }
    else if (rec) recs.delete(node);
  }
  var ATTRS = ['placeholder', 'title', 'aria-label'];
  function attrs(el) {
    ATTRS.forEach(function (a) {
      if (!el.hasAttribute || !el.hasAttribute(a)) return;
      var k = 'data-i18n-' + a, cur = el.getAttribute(a), saved = el.getAttribute(k);
      if (lang === 'ar') { if (saved != null) { if (cur !== saved) el.setAttribute(a, saved); el.removeAttribute(k); el.removeAttribute(k + '-out'); } return; }
      var base = saved != null && el.getAttribute(k + '-out') === cur ? saved : cur;
      var out = tr(base);
      if (out != null) {
        if (saved == null || base !== saved) el.setAttribute(k, base);
        if (el.getAttribute(k + '-out') !== out) el.setAttribute(k + '-out', out);
        if (cur !== out) el.setAttribute(a, out);   // ما نعاودوش نكتبو نفس القيمة: كتحرّك المراقب فحلقة
      }
    });
  }
  function walk(root) {
    if (!root) return;
    if (root.nodeType === 3) { text(root); return; }
    if (root.nodeType !== 1) return;
    var tag = root.tagName;
    if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'TEXTAREA' || tag === 'CODE' || tag === 'PRE' || tag === 'IFRAME' || root.hasAttribute('data-no-i18n')) return;
    attrs(root);
    for (var c = root.firstChild; c; c = c.nextSibling) walk(c);
  }
  function watch() {
    if (obs) return;
    obs = new MutationObserver(function (list) {
      list.forEach(function (m) {
        if (m.type === 'characterData') text(m.target);
        else if (m.type === 'attributes') attrs(m.target);
        else m.addedNodes.forEach(walk);
      });
    });
    obs.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  }
  function setLang(l) {
    if (l !== 'ar' && !(l in IDX)) l = 'ar';
    lang = l;
    try { localStorage.setItem(KEY, l); } catch (_) {}
    document.documentElement.lang = l;
    document.documentElement.dir = l === 'ar' ? 'rtl' : 'ltr';
    walk(document.body);
    var s = document.getElementById('m1li-lang-sel'); if (s) s.value = l;
    var b = document.getElementById('m1li-lang-bar'); if (b) b.remove();
  }
  function settingsRow() {
    var h = document.querySelector('#view-settings h2'); if (!h || document.getElementById('m1li-lang-sel')) return;
    var row = document.createElement('div'); row.className = 'flex items-center justify-between gap-4';
    row.innerHTML = '<div><div class="font-bold text-sm text-white">اللغة</div><div class="text-xs text-slate-400">اختر لغة الواجهة</div></div>' +
      '<select id="m1li-lang-sel" class="px-3 py-2 bg-slate-700 text-white rounded-lg text-sm font-semibold" aria-label="Language">' +
      '<option value="ar">العربية</option><option value="fr">Français</option><option value="en">English</option><option value="es">Español</option></select>';
    h.parentNode.insertBefore(row, h.nextSibling);
    var sel = row.querySelector('select'); sel.value = lang; sel.onchange = function () { setLang(sel.value); };
    walk(row);
  }
  function suggest() {
    var saved = null; try { saved = localStorage.getItem(KEY); } catch (_) {}
    if (saved) return;
    var nav = String(navigator.language || 'ar').slice(0, 2).toLowerCase();
    if (!(nav in IDX)) return;
    var t = SUGGEST[nav], b = document.createElement('div'); b.id = 'm1li-lang-bar'; b.setAttribute('data-no-i18n', '');
    b.style.cssText = 'position:fixed;left:12px;right:12px;top:calc(10px + env(safe-area-inset-top,0px));z-index:99998;background:#0f172a;color:#fff;border:1px solid #334155;border-radius:14px;padding:10px 12px;display:flex;gap:10px;align-items:center;font:600 14px system-ui,sans-serif;box-shadow:0 6px 24px rgba(0,0,0,.35)';
    var sp = document.createElement('span'); sp.style.flex = '1'; sp.textContent = t[0]; sp.dir = 'auto';
    var yes = document.createElement('button'); yes.textContent = t[1]; yes.style.cssText = 'background:#1877f2;color:#fff;border:0;border-radius:9px;padding:7px 14px;font-weight:800';
    yes.onclick = function () { setLang(nav); };
    var no = document.createElement('button'); no.textContent = 'العربية'; no.style.cssText = 'background:none;border:1px solid #475569;color:#cbd5e1;border-radius:9px;padding:7px 12px';
    no.onclick = function () { try { localStorage.setItem(KEY, 'ar'); } catch (_) {} b.remove(); };
    b.appendChild(sp); b.appendChild(yes); b.appendChild(no); document.body.appendChild(b);
  }
  function init() {
    var saved = null; try { saved = localStorage.getItem(KEY); } catch (_) {}
    settingsRow(); watch();
    if (saved && saved !== 'ar' && saved in IDX) setLang(saved); else suggest();
  }
  window.M1LI_SET_LANG = setLang;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
