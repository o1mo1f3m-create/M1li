var CACHE = 'm1li-v65';
var SHELL = ['./', 'index.html', 'shop.js', 'm1li-views.js', 'products.json', 'config.js', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png', 'icon-maskable-512.png', 'design.css', 'home.css', 'facebook.css', 'apps-extra.js', 'publish.js', 'ai-chat.js', 'adsense.js', 'privacy.html', 'about.html', 'start.html', 'app-reviews.js', 'tasks-ui.js', 'compare.html', 'compare.json', 'track.html', 'blog.html', 'contact.html', 'post-atomic.html', 'post-richdad.html', 'post-subtle.html', 'post-alchemist.html', 'post-deepwork.html', 'post-psychmoney.html', 'post-sevenhabits.html', 'post-thinkfast.html', 'post-ikigai.html', 'post-onlinebuy.html', 'post-readmore.html', 'publish.css', 'services.js', 'services.css', 'services.json', 'cover.png', 'offline.html', 'pwa.js', 'i18n.js', 'orders.js'];

self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(CACHE).then(function (c) { return Promise.all(SHELL.map(function (u) { return c.add(u).catch(function () {}); })); }).then(function () { return self.skipWaiting(); }));
});
self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (keys) {
    return Promise.all(keys.filter(function (k) { return k !== CACHE; }).map(function (k) { return caches.delete(k); }));
  }).then(function () { return self.clients.claim(); }));
});
self.addEventListener('fetch', function (e) {
  var req = e.request;
  if (req.method !== 'GET') return;
  var url = new URL(req.url);
  if (url.protocol !== 'http:' && url.protocol !== 'https:') return;
  if (url.hostname === 'accounts.google.com' || url.hostname === 'www.googleapis.com') return;   // Google Sign-In: لا تخزين
  if (/(^|\.)(googlesyndication\.com|doubleclick\.net|googleadservices\.com|adtrafficquality\.google)$/.test(url.hostname) || (url.hostname === 'www.google.com' && url.pathname.indexOf('/pagead') === 0)) return;   // إعلانات AdSense: لا تخزين أبداً
  if (url.pathname.indexOf('/api/') !== -1) return;   // طلبات السيرفر (عدّادات/توكنات) لا تُخزَّن أبداً
  var sameOrigin = url.origin === location.origin;
  // network-first: المنتجات والصفحة تتحدث دائماً عند وجود إنترنت
  if (sameOrigin) {
    e.respondWith(fetch(req).then(function (res) {
      if (res && res.ok) { var copy = res.clone(); caches.open(CACHE).then(function (c) { c.put(req, copy); }).catch(function () {}); }
      return res;
    }).catch(function () { return caches.match(req).then(function (m) { return m || caches.match('index.html'); }); }));
  } else {
    // CDN (Tailwind / FontAwesome / Fonts): cache-first
    e.respondWith(caches.match(req).then(function (m) {
      return m || fetch(req).then(function (res) {
        if (res && (res.ok || res.type === 'opaque')) { var copy = res.clone(); caches.open(CACHE).then(function (c) { c.put(req, copy); }).catch(function () {}); }
        return res;
      });
    }));
  }
});

// ===== إشعارات Push (كتخدم ملي السيرفر كيرسل push؛ وكتخدم محلياً بـ showNotification) =====
self.addEventListener('push', function (e) {
  var d = {};
  try { d = e.data ? e.data.json() : {}; } catch (_) { d = { body: e.data ? e.data.text() : '' }; }
  var title = d.title || 'm1li';
  e.waitUntil(self.registration.showNotification(title, {
    body: d.body || '', icon: 'icon-192.png', badge: 'icon-192.png', dir: 'rtl', lang: 'ar',
    data: { url: d.url || './index.html' }
  }));
});
self.addEventListener('notificationclick', function (e) {
  e.notification.close();
  var url = (e.notification.data && e.notification.data.url) || './index.html';
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (list) {
    for (var i = 0; i < list.length; i++) { if ('focus' in list[i]) { list[i].navigate(url); return list[i].focus(); } }
    return self.clients.openWindow(url);
  }));
});
self.addEventListener('message', function (e) { if (e.data === 'skip-waiting') self.skipWaiting(); });
