/* دخول الإدارة بـ Google: كيشتغل غير بحساب Gmail المطابق لـ ADMIN_EMAIL فالسيرفر */
(function () {
  window.M1AdminGoogleInit = function (onToken, say) {
    var box = document.getElementById('admin-g');
    if (!box || !window.API) return;
    fetch(API + '/api/config', { cache: 'no-store' }).then(function (r) { return r.json(); }).then(function (c) {
      var id = c && c.googleClientId; if (!id) { box.textContent = 'الدخول بـ Google غير مفعّل فالسيرفر (GOOGLE_CLIENT_ID).'; return; }
      function render() {
        google.accounts.id.initialize({ client_id: id, ux_mode: 'popup', callback: function (resp) {
          if (!resp || !resp.credential) return; say('...');
          fetch(API + '/api/admin-login/google', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ credential: resp.credential }) })
            .then(function (r) { return r.json(); }).then(function (j) {
              if (j && j.ok && j.token) { say(''); onToken(j.token); return; }
              var m = { bad_credentials: 'هاد الحساب ماشي حساب الإدارة', too_many_attempts: 'محاولات كثيرة، انتظر 10 دقائق', admin_google_disabled: 'ADMIN_EMAIL أو GOOGLE_CLIENT_ID ناقصين فالسيرفر', bad_google_token: 'تعذّر التحقق من Google' };
              say(m[j && j.error] || 'خطأ');
            }).catch(function () { say('تعذّر الاتصال بالسيرفر'); });
        } });
        google.accounts.id.renderButton(box, { theme: 'filled_blue', size: 'large', shape: 'pill', text: 'signin_with', width: 280 });
      }
      if (window.google && google.accounts) { render(); return; }
      var sc = document.createElement('script'); sc.src = 'https://accounts.google.com/gsi/client'; sc.async = true; sc.defer = true; sc.onload = render;
      sc.onerror = function () { box.textContent = 'تعذّر تحميل Google.'; };
      document.head.appendChild(sc);
    }).catch(function () {});
  };
})();
